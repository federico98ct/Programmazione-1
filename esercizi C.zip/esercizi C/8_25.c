/*scrivete un programma che legga codice ascii e stampi il carattere corrispondente*/
#include <stdio.h>

int main() {
    int codice_ascii;

    printf("Inserisci un codice ASCII (0-127): ");
    scanf("%d", &codice_ascii);

    if (codice_ascii >= 0 && codice_ascii <= 127) {
        printf("Il carattere corrispondente e': %c\n", codice_ascii);
    } else {
        printf("Codice ASCII non valido! Deve essere tra 0 e 127.\n");
    }

    return 0;
}
