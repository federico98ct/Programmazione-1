/*(confronto di porzioni di stringhe) scrivete un programma che usi la funziona strncmp per confrontare due stringhe inserite
dall'utente. il programma deve leggere il numero di caratteri da confrontare, quindi stampare se la prima stringa è minore, maggiore
o uguale alla seconda*/
#include <stdio.h>
#include <string.h>

#define SIZE 100

int main() {
    char a[SIZE];
    char b[SIZE];
    int n;

    printf("Inserisci la prima stringa: ");
    fgets(a, SIZE, stdin);
    a[strcspn(a, "\n")] = '\0';  // Rimuove il newline

    printf("Inserisci la seconda stringa: ");
    fgets(b, SIZE, stdin);
    b[strcspn(b, "\n")] = '\0';  // Rimuove il newline

    printf("Quanti caratteri vuoi confrontare? ");
    scanf("%d", &n);

    int result = strncmp(a, b, n);

    if (result < 0)
        printf("La prima stringa e' **minore** della seconda nei primi %d caratteri.\n", n);
    else if (result > 0)
        printf("La prima stringa e' **maggiore** della seconda nei primi %d caratteri.\n", n);
    else
        printf("Le due stringhe sono **uguali** nei primi %d caratteri.\n", n);

    return 0;
}