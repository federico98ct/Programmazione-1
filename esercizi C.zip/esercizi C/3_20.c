/*sviluppate un programma per calcolare lo stipendio lordo di ciascuno dei diversi impiegati. l'azienda paga quanto previsto all'ora
per "l'orario lavorativo normale" per le prime 40 ore di lavoro e paga "una volta e mezza" per tutte le ore di lavoro oltre le 40 ore.  
vi vengono dati una lista di impiegati dell'azienda, il numero di ore in cui l'impiegato ha lavorato l'ultima settimana e la paga
oraria di ogni impiegato. il vostro programma deve usatre scanf per leggere queste informazioni per ogni impiegato e deteminare
e stampare lo stipendio lordo */

#include <stdio.h>

int main()
{
    const int orario_ordinario =40;
    const double straordinario =1.5;

    double paga_oraria =0;
    int ore_lavorative =0;
    int numero_lavoratore =1;
    

    while (ore_lavorative >= 0)
    {
        printf("\nlavoratore n.%d\n", numero_lavoratore);
        printf("inserire numero di ore lavorative (-1 per uscire): ");
        scanf("%d", &ore_lavorative);

        if(ore_lavorative < 0 )
            break;

        printf("inserire paga oraria: ");
        scanf("%lf", &paga_oraria);

        if (ore_lavorative <= orario_ordinario )
        {
            printf("lo stipendio e': $%.2f\n", (double)ore_lavorative * paga_oraria);        
        }
        else
            printf("lo stipendio e': $%2.f\n", (double)orario_ordinario * paga_oraria + ((double)ore_lavorative - (double)orario_ordinario) * straordinario * paga_oraria);

        numero_lavoratore++;
        
    }
    
}