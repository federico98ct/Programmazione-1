/*date le seguenti definizioni di strutture e di variabili*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct customer {
    char lastName[15];
    char firstName[15];
    unsigned int customerNumber;

    struct {
        char phoneNumber[11];
        char address[50];
        char city[15];
        char state[3];
        char zipCode[6];
    }personal;

}customerRecord, *customerPtr;

int main(){
    customerPtr = &customerRecord;
    //scrivete un espressione utilizzabile per accedere ai membri delle strutture in ognuna delle seguenti parti:

    //a) Membro lastName della stuttura customerRecord.
    printf("inserisci il cognome: ");
    scanf("%14s", customerRecord.lastName);

    //b) membro lastName della strutturapuntata da customerRecord;
    printf("cognome: %s\n", customerPtr->lastName);

    //c) membro firstName della struttura customerRecord;
    printf("inserisci il nome: ");
    scanf("%14s", customerRecord.firstName);

    //d) membro firstName della struttura puntata da customerPtr;
    printf("nome: %s\n", customerPtr->firstName);

    //e) membro customerNumber della struttura customerRecord;
    printf("inserisci il codice cliente: ");
    scanf("%u", &customerRecord.customerNumber);

    //f) membro customerNumber della struttura puntata da customerPtr;
    printf("codice cliente: %u\n", customerPtr->customerNumber);

    //g) membro phoneNumber del membro personal della struttura customerRecord;
    printf("inserisci il numero di telefono: ");
    scanf("%10s", customerRecord.personal.phoneNumber);

    //h) membro phoneNumber del membro personal della struttura puntata da customerPtr;
    printf("numero di telefono: %s\n", customerPtr->personal.phoneNumber);

    //i) membro address del membro personal della struttura customerRecord;
    printf("inserisci l'indirizzo: ");
    scanf("%49s", customerRecord.personal.address);

    //j) membro address del membro personal della struttura puntata da customerptr;
    printf("indirizzo: %s\n", customerPtr->personal.address);

    //k) membro city del membro personal della struttura customerRecord;
    printf("inserisci citta': ");
    scanf("%14s", customerRecord.personal.city);

    //l) membro city del membro personal della struttura puntata da customerPtr;
    printf("citta': %s\n", customerPtr->personal.city);

    //m) membro state del membro personal della struttura customerRecord;
    printf("inserisci stato: ");
    scanf("%2s", customerRecord.personal.state);

    //n) membro state del membro personal della struttura puntata da customerPtr;
    printf("stato: %s\n", customerPtr->personal.state);

    //o) membro zipCode del membro personal della struttura customerRecord;
    printf("inserisci codice postale: ");
    scanf("%5s", customerRecord.personal.zipCode);

    //p) membro zipCode del membro personal della struttura puntata da customerptr;
    printf("codice postale: %s\n", customerPtr->personal.zipCode);
}