/*definite una funzione chiamata hypotenuse che calcoli la lunghezza dell'ipotenusa di un triangolo rettangolo quando sono dati gli
altri due lati. la funzione deve ricevere due argomenti di tipo double e restituire l'ipotenusa come un double.*/
#include <stdio.h>
#include <math.h>

double ipotenusa(double lato1, double lato2);

int main(){
    double lato1 = 0;
    double lato2 = 0;

    printf("inserisci i due lati: ");
    scanf("%lf%lf", &lato1, &lato2);
    printf("la lunghezza dell'ipotenusa e': %.2f cm", ipotenusa(lato1, lato2));
}

double ipotenusa(double lato1, double lato2){
    return sqrt(pow(lato1, 2) + pow(lato2, 2));
}