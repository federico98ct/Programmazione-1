/*scrivete una funzione ricorsiva power(base,exponent) che quando viene invocata restitisca base^exponent. supponete che exponent
sia un intero maggiore o uguale a 1*/
#include <stdio.h>

int potenza(int base, int esponente);

int main(){
    int base = 0;
    int esponente = 0;

    printf("inserisci la base e l'esponente: ");
    if(scanf("%d%d", &base, &esponente) == 2 && esponente >= 0){
        printf("%d", potenza(base, esponente));
    }
    else{
        printf("inserisci dei dati validi.\n");
    }
}

int potenza(int base, int esponente){
    if(esponente == 0){
        return 1;
    }
    return base * potenza(base, esponente-1);
}