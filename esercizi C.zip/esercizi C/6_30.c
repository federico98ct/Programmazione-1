/*in questo esercizio userete il setaccio di Eratostene per trovare tutti i numeri primi inferiori a 1000. esso opera come segue:
a) create un array di 100 elementi, tutti inizializzati a 1 (vero). gli elementi dell'array con indici primi rimarranno con valore 
    1. tutti gli altri elementi dell'array saranno alla fine impostati a zero.
b) partendo dall'indice 2 (l'indice 1 non è primo), ogni volta che si trova un elemento dell'array il cui valore è 1, effettuate 
    un'iterazione lungo il resto dell'array e impostate a zero ogni elemento il cui indice è un multiplo dell'indice dell'elemento 
    con valore 1. per l'indice 2 dell'array, tutti gli elementi che seguono nell'array che sono multipli di 2 saranno impostati a 0.
    per l'indice 3 dell'array, tutti gli elementi successivi nell'array che sono multipli di 3 saranno impostati a 0.
    al termine di questo processo, gli elementi dell'array che hanno ancora il valore 1 indicano che l'indice corrispondente è un numero 
    primo. scrivete un programma che determini e stampi i numeri primi tra 1 e 999. ignorate l'elemento 0 dell'array.*/
#include <stdio.h>

#define SIZE 1000

int main(){
    int numeriPrimi[SIZE];

    for(size_t i = 0; i < SIZE; i++){
        numeriPrimi[i] = 1;
    }

    numeriPrimi[0] = 0;
    numeriPrimi[1] = 0;

    for(size_t i = 2; i < SIZE; i++){

        if(numeriPrimi[i] == 1){
            for (size_t x = i * i; x < SIZE; x += i)
            {
                numeriPrimi[x] = 0;
            }
        }

    }

    for (size_t i = 1; i < SIZE; i++)
    {
        if(numeriPrimi[i] == 1){
            printf("%d ", i);
        }
    }
    
}