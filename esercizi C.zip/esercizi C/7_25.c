/*realizzate un programma guidato da menù che permetta all'utente di scegliere se calcolare la circonferenza di un cerchio, l'area di
un cerchio o il volume di una sfera. il programma deve poi leggere il valore del raggio fornito dall'utente, eseguire il calcolo appropriato
e stampare il risultato. usate un array di puntatori a funzioni in cui ogni puntatore rappresenta una funzione che restituisce
void e riceve un parametro double. le funzioni corrispondenti devono stampare ognuna un messaggio che indica quale calcolo
è stato eseguito, il valore del raggio e il risultato del calcolo*/
#include <stdio.h>

void circonferenzaCerchio(double x);
void areaCerchio(double x);
void volumeSfera(double x);

int main(){
    void (*sceltaOperazione[3])(double) = {circonferenzaCerchio, areaCerchio, volumeSfera};
    int choice = 0;
    double raggio = 0.0;

    printf("%s\n%s\n%s\n%s\n\n",
        " 0 circonferenza cerchio",
        " 1 area del cerchio",
        " 2 volume della sfera",
        " 3 per finire");

    while(1){
        printf("scegli che operazione eseguire: ");
        if(scanf("%d", &choice) == 0 || choice < 0 || choice > 3){
            printf("inserisci un valore valido: ");
            while (getchar() != '\n');
            continue;
        }

        if(choice == 3) break;

        printf("inserisci il raggio: ");
        while(scanf("%lf", &raggio) != 1){
            printf("inserisci un valore valido: ");
            while (getchar() != '\n');
        }

        (*sceltaOperazione[choice])(raggio);
    }
}

void circonferenzaCerchio(double x){
    printf("\nstiamo eseguendo il calcolo della circonferenza\n");
    printf("il raggio e' : %.2f\nil risultato e': %.2f\n\n", x, 2 * 3.14 * x);
}

void areaCerchio(double x){
    printf("\nstiamo eseguendo il calcolo dell'area del cerchio\n");
    printf("il raggio e' : %.2f\nil risultato e': %.2f\n\n", x, 3.14 * x * x);
}

void volumeSfera(double x){
    printf("\nstiamo eseguendo il calcolo del volume della sfera\n");
    printf("il raggio e' : %.2f\nil risultato e': %.2f\n\n", x, (4.0 / 3.0) * 3.14 * x * x * x);
}

