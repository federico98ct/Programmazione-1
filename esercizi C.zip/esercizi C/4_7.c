/*scrivete delle istruzioni for che stampino le seguenti sequenze di valori: */
#include <stdio.h>

int main(){

/*1,2,3,4,5,6,7*/
for (int i = 1; i <= 7; i++)
{
    printf("%d,", i);
}

printf("\n");

/*3,8,13,18,23*/
for(int i = 0; i <= 23; i += 5 )
{
    printf("%d,", 3 + i);
}

printf("\n");

int numero_2 = 20;
/*20,14,8,2,-4,-10*/
for(int numero = 20; numero >= -10; numero -= 6)
{
    printf("%d,", numero);
}

printf("\n");

/*19,27,35,43,51*/
for(int numero = 19; numero <= 51; numero +=8){
    printf("%d,", numero);
}
}
