/*(concatenamento di liste) scrivete un programma che concateni due liste collegate di caratteri. il programma deve includere 
la funzione concatenate che riceve come argomenti i puntatori a entrambe le liste e concatena la seconda lista alla prima*/
#include <stdio.h>
#include <stdlib.h>

struct lista{
    char c;
    struct lista* nextPtr;

};

typedef struct lista Lista;
typedef Lista* ListaPtr;

void insert(ListaPtr *lPtr, char c);
void concatenate(ListaPtr *l1, ListaPtr l2); //concatenamento di list
void stampaLista(ListaPtr lPtr);
ListaPtr merge(ListaPtr l1, ListaPtr l2); //fusione di liste
void distruggiLista(ListaPtr *sPtr);

int main(){
    ListaPtr l1 = NULL;
    ListaPtr l2 = NULL;

    insert(&l1, 'd');
    insert(&l1, 'z');
    insert(&l1, 'a');

    insert(&l2, 'x');
    insert(&l2, 'f');
    insert(&l2, 'u');

    ListaPtr l3 = merge(l1, l2);
    stampaLista(l3);
    //concatenate(&l1, l2);
   // stampaLista(l1);
   distruggiLista(&l1);
   distruggiLista(&l2);
}

void insert(ListaPtr *lPtr, char c){
    ListaPtr newPtr = malloc(sizeof(Lista));
    if(newPtr != NULL){
        newPtr->c = c;
        newPtr->nextPtr = NULL;

        ListaPtr previousPtr = NULL;
        ListaPtr currentPtr = *lPtr;

        while(currentPtr != NULL && c > currentPtr->c){
            previousPtr = currentPtr;
            currentPtr = currentPtr->nextPtr;
        }
        if(previousPtr == NULL){
            newPtr->nextPtr = *lPtr;
            *lPtr = newPtr;
        }
        else{
            previousPtr->nextPtr = newPtr;
            newPtr->nextPtr = currentPtr;
        }

    }
    else{
        printf("nessuno spazio in memoria\n");
        return;
    }
}

void concatenate(ListaPtr *l1, ListaPtr l2){
    if (*l1 == NULL) {
        *l1 = l2;
    } 
    else {
        ListaPtr currentPtr = *l1;
        while (currentPtr->nextPtr != NULL) {
            currentPtr = currentPtr->nextPtr;
        }
        currentPtr->nextPtr = l2;
    }
}

void stampaLista(ListaPtr lPtr){
    if(lPtr == NULL){
        printf("la lista e' vuota\n");
        return;
    }
    while(lPtr != NULL) {
        printf("--> %c ", lPtr->c);
        lPtr = lPtr->nextPtr;
    }
    printf("--> NULL\n");
}

ListaPtr merge(ListaPtr l1, ListaPtr l2){
    Lista nodoFittizio;
    ListaPtr l3 = &nodoFittizio;
    nodoFittizio.nextPtr = NULL;

    while(l1 != NULL && l2 != NULL){
        if(l1->c <= l2->c){
            l3->nextPtr = l1;
            l1 = l1->nextPtr;
        }
        else{
            l3->nextPtr = l2;
            l2 = l2->nextPtr;
        }
        l3 = l3->nextPtr;
    }

    l3->nextPtr = (l1 != NULL) ? l1 : l2;
    return nodoFittizio.nextPtr;
}

void distruggiLista(ListaPtr* sPtr){
    while(*sPtr != NULL){
        ListaPtr temp = *sPtr;
        *sPtr = (*sPtr)->nextPtr;
        free(temp);
    }
}