/*(usare funzioni per l'elaborazioni di file con stream di input output standard) modificate l'esempio della figura 8.8 in modo
da usare le funzioni fgetc e fputs al posto di getchar e puts. il programma deve offrire all'utente l'opzione di poter leggere 
dallo standard input e scrivere sullo standard output, oppure di leggere da un file specifico e scrivere su un file specificato.
se l'utente sceglie la seconda opzione, fate si che inserisca i nomi dei file di input e output*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 1000

void reverse(const char *sPtr, FILE *out);

int main() {
    char source[SIZE], dest[SIZE];
    FILE *inFile = NULL, *outFile = NULL;
    char sentence[SIZE] = "";

    printf("Scegli un'opzione:\n");
    printf("1. Leggi da standard input e scrivi su standard output\n");
    printf("2. Leggi da file e scrivi su file\n");
    printf("Scelta: ");

    int choice = fgetc(stdin);
    fgetc(stdin); // consuma il newline

    if (choice == '1') {
        fputs("Inserisci una riga di testo:\n", stdout);
        int i = 0;
        int ch;
        while (i < SIZE - 1 && (ch = fgetc(stdin)) != '\n' && ch != EOF) {
            sentence[i++] = (char)ch;
        }
        sentence[i] = '\0';
        fputs("\nLa linea invertita e':\n", stdout);
        reverse(sentence, stdout);
        fputs("\n", stdout);
    } else if (choice == '2') {
        fputs("Nome file di input: ", stdout);
        fgets(source, SIZE, stdin);
        source[strcspn(source, "\n")] = '\0'; // rimuove newline

        fputs("Nome file di output: ", stdout);
        fgets(dest, SIZE, stdin);
        dest[strcspn(dest, "\n")] = '\0';

        inFile = fopen(source, "r");
        outFile = fopen(dest, "w");

        if (!inFile || !outFile) {
            fputs("Errore nell'apertura dei file.\n", stderr);
            return 1;
        }

        int i = 0;
        int ch;
        while (i < SIZE - 1 && (ch = fgetc(inFile)) != EOF && ch != '\n') {
            sentence[i++] = (char)ch;
        }
        sentence[i] = '\0';

        fputs("La linea invertita e':\n", outFile);
        reverse(sentence, outFile);
        fputs("\n", outFile);

        fclose(inFile);
        fclose(outFile);
    } else {
        fputs("Scelta non valida.\n", stderr);
    }

    return 0;
}

void reverse(const char *sPtr, FILE *out) {
    if (*sPtr == '\0')
        return;

    reverse(sPtr + 1, out);
    fputc(*sPtr, out);
}