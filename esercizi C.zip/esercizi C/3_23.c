/*scrivete un programma che utilizzi scanf per leggere una serie di 10 numeri non-negativi e determini e stampi il maggiore.*/

#include <stdio.h>

int main()
{
    int i =10; //contatore
    int numero =0; //numero da inserire
    int maggiore =0; //maggiore fino aquel momento

    printf("programma che somma 10 numeri inseriti dall'utente\n");
    while (i > 0)
    {
        printf("inserisci un numero: ");
        if(scanf("%d", &numero) == 1 && numero >= 0){
            i--;
            if(numero > maggiore)
                maggiore = numero;
        }
        else{
            printf("valore errato, riprovare.\n");
            continue;
        }   
    }
    if(i==0)
        printf("il maggiore e': %d", maggiore);
}