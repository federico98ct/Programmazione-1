/*sviluppare un programma in c per determinare se un cliente di un grande magazzino ha superato il limite di credito sul suo
conto di addebito. per ogni cliente sono a disposizione i seguenti dati:
    a)numero del conto
    b)saldo all'inizio del mese
    c)totale delle voci addebitate sul conto del cliente nel mese
    d)totale dei crediti applicati nel mese al conto del cliente
    e)limite di credito concesso
il programma deve usare scanf per leggere tali dati, calcolare il nuovo saldo (=saldo iniziale+addebiti-crediti) e determinare
se il nuovo saldo supera il limite di credito del cliente. per quei clienti il cui limite di credito è stato superato, 
il programma deve stampare il numero del conto del cliente, il limite di credito, il nuovo saldo e il messaggio "limite di credito superato"
*/

#include <stdio.h>

int main()
{
    int numero_conto =0; //numero del conto del cliente
    double saldo_inizio =0; //saldo iniziale del cliente ad inizio mese
    double totale_addebiti =0; //totale delle voci addebitate sul conto del cliente durante il mese
    double totale_crediti_applicati =0; //totale dei crediti applicati durante il mese
    double limite_credito_concesso =0; //limite del credito concesso

    while (numero_conto != -1)
    {
        printf("\ninserire numero de conto(-1 per uscire): ");
        scanf("%d", &numero_conto);

        if(numero_conto <=-1)
            break;
 
        printf("inserire saldo ad inizio mese: ");
        scanf("%lf", &saldo_inizio);
        printf("inserire totale degli addebiti: ");
        scanf("%lf", &totale_addebiti);
        printf("inserire totale crediti applicati: ");
        scanf("%lf", &totale_crediti_applicati);
        printf("inserire limite di credito concesso: ");
        scanf("%lf", &limite_credito_concesso);

        double nuovo_saldo = saldo_inizio + totale_addebiti - totale_crediti_applicati;

        if (nuovo_saldo > limite_credito_concesso )
        {
            printf("numero cliente: %d\nlimite di credito: %.2f\nnuovo saldo: %.2f\nlimite di credito superato!\n", numero_conto, limite_credito_concesso, nuovo_saldo);
        }
    }
}