#include <stdio.h>

int main(){
    int c = '\0';

    if((c = getchar()) != EOF){
        printf("%c", c);
        main();
        
    }
}