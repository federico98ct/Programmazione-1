/*i guidatori sono interessato al consumo effettuato dalle loro automobili. un guidatore ha tenuto traccia dei vari pieni di 
carburante, registrando le miglia percorse e i galloni consumati per ogni pieno. realizzate un programma che utilizzi scanf
per richiedere l'inserimento delle miglia percorse e dei galloni consumati per ogni pieno. il programma deve calcolare e stampare 
le miglia per gallone percorse per ogni pieno. dopo aver processato tutte le informazioni di input, il programma deve calcolare e stampare 
le miglia complessive per gallone percorso per tutti i pieni*/

#include <stdio.h>

int main()
{
    int miglia_percorse =0;
    int galloni_consumati =0;
    double miglia_per_gallone =0;
    int miglia_totali =0;
    int galloni_totali =0;

    while (miglia_percorse != -1)
    {
        printf("\ninserisci le miglia percorse (inserire -1 per finire): ");
        scanf("%d", &miglia_percorse);

        if (miglia_percorse == -1)
        break;
    
        printf("inserisci i galloni consumati: ");
        scanf("%d", &galloni_consumati);
            
        if (galloni_consumati > 0)
        {
            miglia_per_gallone = (double)miglia_percorse/galloni_consumati;
            printf("le miglia/gallone per queto pieno sono: %.2f\n", miglia_per_gallone);
        }
        else
            printf("inserire un numero valido di galloni consumati!\n");

        miglia_totali += miglia_percorse;
        galloni_totali += galloni_consumati;
    }
    
    printf("la media totale di miglia/gallone e' di: %.2f",(double)miglia_totali/galloni_totali);
}