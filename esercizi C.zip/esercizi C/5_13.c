#include <stdio.h>
#include <stdlib.h>

int generaNumero(int min, int max);

int main(){
    for(int i= 1; i <= 30; i++){
        printf("%d ", generaNumero(1, 2));
    }
    puts("");
    for(int i= 1; i <= 10; i++){
        printf("%d ",  generaNumero(1, 100));
    }
    puts("");
    for(int i= 1; i <= 10; i++){
        printf("%d ",  generaNumero(0, 9));
    }
    puts("");
    for(int i= 1; i <= 10; i++){
        printf("%d ",  generaNumero(1000, 1112));
    }
    puts("");
    for(int i= 1; i <= 10; i++){
        printf("%d ",  generaNumero(-1, 1));
    }
    puts("");
    for(int i= 1; i <= 10; i++){
        printf("%d ",  generaNumero(-3, 11));
    }
}

int generaNumero(int min, int max) {  //importante per la creazione di intervalli per la generazione di numeri casuali
    return min + (rand() % (max - min + 1));
}