/*scrivete un programma che stampi sulla stessa riga i numeri da uno a 4.
scrivete il programma usando i seguenti metodi. */

#include <stdio.h>

int main()
{
    printf("1 2 3 4\n");                       // a)uso di una sola istruzione printf senza specifiche di conversione

    printf("%d %d %d %d\n", 1, 2, 3, 4);       // b)uso di suna sola istruzione printf con quattro specifiche di conversione

    printf("1 ");                              // c)uso di quatto istruzioni printf
    printf("2 ");
    printf("3 ");
    printf("4 ");
}