/*(conteggio delle lettere dell'alfabeto in una stringa) scrivete un programma basato sull'esercizio precedente che legga diverse
righe di testo e che usi la funzione strchr per determinare il totale delle volte in cui ogni lettera dell'alfabeto compare nelle 
righe di testo. le lettere maiuscole e minuscole vanno contate insieme. memorizzate i totali per ogni lettera in un array e stampate
i valori in formato tabellare dopo che sono stati determinat i totali*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define SIZE 100
#define MAX_RIGHE 10
#define LETTERE 26

void chiediStringa(char stringa[]);
void convertiMinuscolo(char stringa[]);
void ricercaOccorrenze(char stringa[], char caratteri[], int risultati[]);
void stampaRisultati(char caratteri[], int risultati[]);

int main(){
    char righe[MAX_RIGHE][SIZE];
    char alfabeto[LETTERE] = {};
   
    int i, nRighe= 0;
    int risultati[LETTERE] = {0};

    for (int i = 0; i < LETTERE; i++) { //alloco l'array con le lettere dell'alfabeto
        alfabeto[i] = 'a' + i; 
    }

    printf("inserisci quante righe vuoi inserire (max 10): "); //chiedi quannte righe si vogliono inserire
    scanf("%d", &nRighe);
    getchar(); //pulizia buffer

    if(nRighe > MAX_RIGHE || nRighe < 1){  //acquisizione righe di testo
        printf("valore di righe non valido\n");
        return 1;
    }

    for (i = 0; i < nRighe; i++){ //inserimento stringhe
        printf("inserisci stringa %d: ", i+1);
        chiediStringa(righe[i]);
    }

   for (i = 0; i < nRighe; i++){ 
        convertiMinuscolo(righe[i]);
        ricercaOccorrenze(righe[i], alfabeto, risultati);
   }

   stampaRisultati(alfabeto, risultati);

}

void chiediStringa(char stringa[]){
    fgets(stringa, SIZE, stdin);
    stringa[strcspn(stringa, "\n")] = '\0';
}

void convertiMinuscolo(char stringa[]){
    for (size_t i = 0; i < strlen(stringa); i++)
    {
        stringa[i] = tolower(stringa[i]);
    }
    
}

void ricercaOccorrenze(char stringa[], char caratteri[], int risultati[]){
    for(int x = 0; x < LETTERE; x++){
                char *ptr = strchr(stringa, caratteri[x]);
                    while(ptr != NULL){
                        risultati[x]++;
                        ptr = strchr(ptr + 1, caratteri[x]);
                    }
    }
}

void stampaRisultati(char caratteri[], int risultati[]){

    for (size_t i = 0; i < LETTERE; i++){
        printf("%5c", caratteri[i]);
    }

    puts("");
    
    for (size_t i = 0; i < LETTERE; i++){
        printf("%5d", risultati[i]);
    }
    
}