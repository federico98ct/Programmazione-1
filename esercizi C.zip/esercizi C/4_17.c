/*scrivete un programma che analizzi lo status di tre clienti di questa azzienda. per ogni cliente vi son dati:
a) il numero di conto del cliente
b) il limite di credito del cliente prima della recessione
c) il saldo attuale di credito del cliente (cioè l'ammontare che il cliente deve all'azienda)
il vostro programma deve calcolare e stampare il nuovo limite di credito per ciascun cliente e determinare (e stampare) quali 
clienti hanno il saldo attuale di credito che supera i loro nuovi limiti di credito.*/
#include <stdio.h>

int main(){
    int numero_conto = 0;
    double limite_credito = 0;
    double saldo = 0;

    for(int i = 1; i <= 3; i++){
        printf("cliente n.%d\n", i);
        printf("inserisci il numero di conto: ");
        scanf("%d", &numero_conto);
        printf("inserisci il limite di credito: ");
        scanf("%lf", &limite_credito);
        printf("inserisci il saldo attuale: ");
        scanf("%lf", &saldo);

        limite_credito /= 2;
        if(saldo > limite_credito){
            printf("il tuo saldo attuale di credito corrispondente a %.2f supera il numo limite di credito di %.2f\n", saldo, limite_credito);
        }
        printf("\n");

    }
}