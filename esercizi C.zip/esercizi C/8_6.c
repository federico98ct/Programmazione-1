/*(stampa di stringhe con caratteri maiuscoli e minuscoli) scrivete un programma che legga una riga di testo e la memorizzi 
nell'array char s[100]. fate stampare la riga sia con lettere maiuscole sia con lettere minuscole*/
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(){
    char s[100];

    printf("inserisci una riga di testo: ");
    fgets(s, sizeof(s), stdin);

    for (size_t i = 0; i < strlen(s); i++)
    {
        printf("%c", toupper(s[i]));
    }

    for (size_t i = 0; i < strlen(s); i++)
    {
        printf("%c", tolower(s[i]));
    }
    
}