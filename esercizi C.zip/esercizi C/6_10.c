/*usate u'array unidimensionale per risolvere il seguente problema. un'azienda paga i suoi agenti di vendita su commissione. gli
agenti di vendita ricevono $200 alla settimana più il 9% delle loro vendite lorde per quella settimana. per esempio, un agente di 
vendita che ottiene un introito lordo sulle vendite di $3000 in una settimana riceve $200 più il 9% di $3000, ovvero un totale di 
$470. scrivete un programma in C (usando un array di contatori) che determini quanti agenti di vendita hanno avuto i loro guadagni
in ognuno dei seguenti intervalli (supponete che ogni agente di vendita sia troncato a una quantità intera):
a) $200 - $299
b) $300 - $399
c) $400 - $499
d) $500 - $599
e) $600 - $699
f) $700 - $799
g) $800 - $899
h) $900 - $999
i) $1000 e oltre*/
#include <stdio.h>

#define STIPENDIO_BASE 200
#define BONUS 0.09

int main(){

    double vendite = 0;
    int count[9] = {0};
    
    while (1)
    {
        printf("inserisci il totale delle vendite per questa settimana: ");
        if(scanf("%lf", &vendite) == 1){

            double stipendio = (vendite * BONUS) + STIPENDIO_BASE;
            printf("lo stipendio e' calcolato sommando alla base fissa di $%u\nil corrispondente 9%% sul totale delle vendite $%.2f = %.0f\n",
                STIPENDIO_BASE, vendite, stipendio);
        
            if(stipendio < 300){
                count[0]++;
            }
            else if(stipendio < 400){
                count[1]++;
            }      
            else if(stipendio < 500){
                count[2]++;
            }
            else if(stipendio < 600){
                count[3]++;
            }
            else if(stipendio < 700){
                count[4]++;
            }
            else if(stipendio < 800){
                count[5]++;
            }
            else if(stipendio < 900){
                count[6]++;
            }
            else if(stipendio < 1000){
                count[7]++;
            }
            else{
                count[8]++;
            }
        }
        else break;
    }

    for (size_t x = 0; x < 9; x++)
    {
        printf("range %zu tale dipendenti: %d\n", x, count[x]);
    }
}