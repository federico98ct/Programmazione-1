#include <stdio.h>
#include <stdlib.h>

int generatoreNumeri(int min, int maxValori, int pattern); 

int main(){
    
    int range = 20;

    for(int i = 1; i <= range; i++){
        printf("%d ", generatoreNumeri(2, 5, 2));
    }
    puts("");
    for(int i = 1; i <= range; i++){
        printf("%d ", generatoreNumeri(3, 5, 2));
    }
    puts("");
    for(int i = 1; i <= range; i++){
        printf("%d ", generatoreNumeri(6, 5, 4));
    }
}

int generatoreNumeri(int min, int maxValori, int pattern){ //funzione utile per generare numeri che seguono un certo pattern regolare
    return min + ((rand() % maxValori) * pattern);
}