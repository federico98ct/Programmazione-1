/*scrivete un programma che calcoli e stampi il prodotto degli interi dispari da 1 a 15*/
#include <stdio.h>

int main(){
    int prodotto =1;

    for (int i = 1; i <= 15; i+=2)
    {
        prodotto *= i;
    }
    
    printf("il prodotto e': %d\n", prodotto);
}