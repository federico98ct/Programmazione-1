#include <stdio.h>
#define STUDENTS 3
#define EXAMS 4

void minimum(const int grades [][EXAMS], size_t pupils, size_t tests);
void maximum(const int grades[][EXAMS], size_t pupils, size_t tests);
void average(const int grades[][EXAMS], size_t pupils, size_t tests);
void printArray(const int grades[][EXAMS], size_t pupils, size_t tests);

int main(){
    void (*processGrades[4])(const int [][EXAMS], size_t, size_t) = {printArray, minimum, maximum, average};

    int studentGrades[STUDENTS][EXAMS] = 
        {{77, 68, 86, 73},
         {96, 87, 89, 78},
         {70, 90, 86, 81}};

    int choice = 0;

    printf("%s\n%s\n%s\n%s\n%s\n\n", 
        " 0 print the array of grades",
        " 1 find the minimum grade",
        " 2 find the maximum grade",
        " 3 print the average on all tests for each student",
        " 4 end program");

        do{
            printf("Enter a choice: ");
            if(scanf("%zu", &choice) == 0 || choice < 0 || choice > 4){
                printf("inserisci un valore corretto\n");
                choice = 0;
                continue;
            }
            puts("");

            (*processGrades[choice])(studentGrades, STUDENTS, EXAMS);
            puts("");
        }while(choice >= 0 && choice <4);

}

void minimum(const int grades[][EXAMS], size_t pupils, size_t tests){
    int lowGrade = 100;

    for(size_t row = 0; row < pupils; row++){
        for(size_t column = 0; column < tests; column++){
            if(grades[row][column] < lowGrade){
                lowGrade = grades[row][column];
            }
        }
    }

    printf("Lowest grade: %d\n", lowGrade);
}

void maximum(const int grades[][EXAMS], size_t pupils, size_t tests){
    int highGrade = 0;
    for(size_t row = 0; row < pupils; row++){
        for(size_t column = 0; column < tests; column++){
            if(grades[row][column] > highGrade){
                highGrade = grades[row][column];
            }
        }
    }

    printf("Highest grade: %d\n", highGrade);
}

void average(const int grades[][EXAMS], size_t pupils, size_t tests){
    for (size_t student = 0; student < pupils; student++){
        int total = 0; 
        for(size_t test = 0; test < tests; test++){
            total += grades[student][test];
        }
         printf("The average grade for student %zu is %.2f\n",
            student, (double) total / tests);
    }
}

void printArray(const int grades[][EXAMS], size_t pupils, size_t tests){
    puts("The array is:");
    printf("%s", "                [0]  [1]  [2]  [3]");

    for(size_t row = 0; row < pupils; row++){
        printf("\nstudentGrades[%zu] ", row);

        for (size_t column = 0; column < tests; column++){
            printf("%-5d", grades[row][column]);
        }
    }
    puts("");
}