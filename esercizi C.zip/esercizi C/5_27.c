#include <stdio.h>
#include <math.h>

int numeroPrimo(int numero);

int main() {
    for (int numero = 1; numero <= 10000; numero++) {
        if (numeroPrimo(numero)) {
            printf(" %d", numero);
        }
    }
    return 0;
}

int numeroPrimo(int numero) {
    if (numero < 2) return 0; // Esclude numeri minori di 2
    if (numero == 2) return 1; // 2 è primo
    if (numero % 2 == 0) return 0; // Esclude numeri pari

    for (int i = 3; i <= sqrt(numero); i += 2) { // Controlla solo numeri dispari fino a sqrt(numero)
        if (numero % i == 0) return 0;
    }
    return 1;
}