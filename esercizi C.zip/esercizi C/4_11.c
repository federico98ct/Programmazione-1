/*scriveteun programma che trovi il più piccolo di diversi numeri interi. supponete che il primo valore letto specifichi il 
numero dei restanti valori*/
#include <stdio.h>

int main(){
    int numero = 0;
    int minore = 0;
    int valori_range = 0;

    while(valori_range <= 0)
    {    
        printf("inserisci il numero di valori da inserire: ");
        scanf("%d", &valori_range);
        
        if(valori_range <= 0){
            printf("inserisci un numero valido maggiore di 0\n");
            continue;
        }
    }

    for ( int i = 1; i <= valori_range; i++)
    {
        printf("inserisci un numero: ");
        scanf("%d", &numero);

        if(i == 1){
            minore = numero;
        }
        else if(numero <= minore){
            minore = numero;
        }
    }

    printf("il minore di questi %d numeri e': %d", valori_range, minore);
    
}