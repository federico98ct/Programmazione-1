/*(conteggio del numero di parole in una stringa) scrivete un programma che legga diverse righe di testo e che usi strtok per 
contare il numero totale di parole. supponete che le parole siano separate o da spazi o da caratteri newline*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 100
#define MAX_RIGHE 10

void chiediStringa(char stringa[]);

int main(){
    char stringhe[MAX_RIGHE][SIZE];
    int nRighe, contatore = 0;

    printf("inserisci il numero di righe da inserire (10 max): ");
    scanf("%d", &nRighe);
    getchar();

    if(nRighe > MAX_RIGHE || nRighe < 1){
        printf("valore non valido\n");
        return 1;
    }

    for (int i = 0; i < nRighe; i++){ //inserimento stringhe
        printf("inserisci stringa %d: ", i+1);
        chiediStringa(stringhe[i]);
    }

    for (int i = 0; i < nRighe; i++){
        char *ptr = strtok(stringhe[i], " \n");
        while (ptr != NULL){
            contatore++;
            ptr = strtok(NULL, " \n");
        }
    }

    printf("il numero totale di parole e': %d", contatore);
    
}

void chiediStringa(char stringa[]){
    fgets(stringa, SIZE, stdin);
    stringa[strcspn(stringa, "\n")] = '\0';
}