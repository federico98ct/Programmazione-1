/*scrivete un programma che calcoli e stampi la media di diversi numeri interi. supponete che l'ultimo numero letto con
scanf sia la sentinella 9999*/
#include <stdio.h>

int main(){

    int numero = 0;
    double media = 0;
    int somma = 0;
    int i = 0;

    do
    {
        i++;    
        somma += numero;
        printf("inserisci un numero: ");
        scanf("%d", &numero);

    } while (numero != 9999);

    media = (double) somma / (i -1);
    printf("la media dei numeri inseriti e': %.2f", media);
    
}