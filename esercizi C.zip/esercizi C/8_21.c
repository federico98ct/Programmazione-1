/*(mettere in ordine alfabetico una lista di stringhe) usate le funzioni per il confronto di stringhe e le tecniche per ordinare 
gli array per scrivere un programma che metta in ordine alfabetico una lista di stringhe. usate i nomi di 10 0 15 città come 
dati per il vostro programma*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    char *citta[] = {"catania", "roma", "palermo", "messina", "udine", "treviso", "padova", "milano", "cagliari", "aquila"};
    int lunghezza = sizeof(citta)/sizeof(citta[0]);

    for (int i = 0; i < lunghezza -1; i++){ //passata
        for(int j = 0; j < lunghezza - 1 - i; j++){

            if(strcmp(citta[j], citta[j + 1]) > 0){
                char *temp = citta[j];
                citta[j] = citta[j + 1];
                citta[j + 1] = temp;
            }
        }
    }
    
    for (int i = 0; i < lunghezza; i++)
    {
        printf("%s\n", citta[i]);
    }
}