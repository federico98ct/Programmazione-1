/*(test di caratteri) scrivete un programma che legga un carattere dalla tastiera e lo testi con ognuna delle funzioni della 
libreria per il trattamneto dei caratteri. il programma deve stampare il valore restituito da ogni funzione*/
#include <stdio.h>
#include <ctype.h>

int main(){
    //TRATTAMENTO DEI CARATTERI. usano la libreria <ctype.h>

    char a = '3';
    printf("%d\n", isdigit(a)); //isdigit()

    char b = 'd';
    printf("%d\n", isalpha(b)); //isalpha()

    char c = 'e';
    printf("%d\n", isalnum(c)); //isalnum()

    char d = 'f';
    printf("%d\n", isxdigit(d)); //isxdigit()

    char space = ' '; 
    printf("%d\n", isspace(space)); //isspace()

    char control = '\n';
    printf("%d0\n", iscntrl(control)); //iscontrl()

    char punct = ',';
    printf("%d\n", ispunct(punct)); //ispunct()

    char print = '()';
    printf("%d\n", isprint(print)); //isprint() include lo spazio

    char graph = 'g';
    printf("%d\n", isgraph(graph)); //isgraph() non include lo spazio

    char e = 'p';
    printf("%d\n", islower(e)); //islower()

    char f = 'F';
    printf("%d\n", isupper(f)); //isupper()

    char g = 'g';
    printf("%d\n", toupper(g)); //toupper()

    char h = 'h';
    printf("%d\n", tolower(h)); //tolower()

}