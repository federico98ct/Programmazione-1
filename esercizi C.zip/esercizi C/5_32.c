/*scrivete un programma che realizzi il gioco "indovina il numero" come segue: il vostro programma sceglie il numero da indovinare
selezionando a caso un intero nell'intervallo da 1 a 1000*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
    int risposta;
    char rigiocare = 'y';

    srand(time(NULL));

    do
    {
        int numero = 1 + (rand() % 1000);
        printf("sto pensando ad un numero tra 1 e 1000.\n");
        printf("riesci ad indovinarlo?\n");

        while(1){
            printf("inserisci la tua risposta: ");
            if(scanf("%d", &risposta) == 1 && risposta >=1 && risposta <= 1000){
                if(risposta > numero){
                    printf("troppo alto. riprova.\n");
                }
                else if(risposta < numero){
                    printf("troppo basso. riprova.\n");
                }
                else{
                    printf("eccellente! hai indovinato il numero!\n");
                    break;
                }
            }
            else{
                printf("inserisci un numero valido\n");
                while (getchar() != '\n'); 
            }
        }

        printf("vorresti rigiocare (y or n)? ");
        scanf(" %c", &rigiocare);

    } while(rigiocare == 'y');    
}