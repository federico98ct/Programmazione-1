/*(suddivisione in token di numeri telefonici) scrivete un programma che legga un numero di telefono come una stringa nella forma 
(555) 555-5555. usate una funzione strtok per estrarre come singoli token il prefisso, le prime tre cifre e infine le ultime quattro cifre
del numero telefonico. concatenate le sette cifre del numero telefonico in un'unica stringa. convertite la stringa del prefisso
e la stringa del numero telefonico in interi, poi stampate entrambi*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 15

int main() {
    int prefisso;
    int numero;
    char parteNumerica[SIZE] = "";

    char numeroTelefonico[SIZE]; // Memorizza il numero telefonico inserito dall'utente
    printf("Inserisci un numero telefonico (es. (555) 555-5555): ");
    fgets(numeroTelefonico, SIZE, stdin);

    // Rimuove il carattere di nuova riga
    numeroTelefonico[strcspn(numeroTelefonico, "\n")] = '\0';

    char *nptr = strtok(numeroTelefonico, "() -");

    if (nptr != NULL) {
        sscanf(nptr, "%d", &prefisso);
    } else {
        printf("Errore: formato del numero non valido\n");
        return 1;
    }

    while ((nptr = strtok(NULL, " -")) != NULL) {
        strncat(parteNumerica, nptr, SIZE - strlen(parteNumerica) - 1);
    }

    if (sscanf(parteNumerica, "%d", &numero) != 1) {
        printf("Errore: impossibile convertire il numero\n");
        return 1;
    }

    printf("Prefisso: %d\n", prefisso);
    printf("Numero telefonico: %d\n", numero);

    return 0;
}