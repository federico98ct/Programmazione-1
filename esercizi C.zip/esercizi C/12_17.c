/*(stampare ricorsivamente una lista all'indietro) scrivete una funzione stampalistaIndietro che stampi in maniera ricorsiva gli 
elementi in una lista in ordine inverso. usate la vostra funzione in un programma di test che crea una lista ordinata di interi 
e stampa la lista in ordine inverso*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct lista{
    int numero;
    struct lista* nextPtr;
};

typedef struct lista Lista;
typedef Lista* ListaPtr;

void insert(ListaPtr* sPtr, int n);
void stampaLista(ListaPtr sPtr);
void stampaListaIndietro(ListaPtr sPtr);
void liberaLista(ListaPtr* sPtr);

int main(){
    srand(time(NULL));
    ListaPtr startPtr = NULL;

    for(size_t i = 0; i < 10; i++){
        int numero = 1 + (rand() % 10);
        insert(&startPtr, numero);
    }
    printf("la lista e':\n");
    stampaLista(startPtr);

    printf("la lista in ordine inverso e':\n");
    stampaListaIndietro(startPtr);
    printf("--> NULL\n");

    liberaLista(&startPtr);
}

void insert(ListaPtr* sPtr, int n){
    ListaPtr newPtr = malloc(sizeof(Lista));

    if(newPtr == NULL){
        printf("memoria esaurita\n");
        return;
    }

    newPtr->numero = n;
    newPtr->nextPtr = NULL;

    ListaPtr previousPtr = NULL;
    ListaPtr currentPtr = *sPtr;

    while(currentPtr != NULL && n > currentPtr->numero){
        previousPtr = currentPtr;
        currentPtr = currentPtr->nextPtr;
    }
    if(previousPtr == NULL){
        newPtr->nextPtr = currentPtr;
        *sPtr = newPtr;
    }
    else{
        previousPtr->nextPtr = newPtr;
        newPtr->nextPtr = currentPtr;
    }
}

void stampaLista(ListaPtr sPtr){
    if(sPtr == NULL){
        printf("la lista e' vuota\n");
        return;
    }
    while(sPtr != NULL){
        printf("--> %d ", sPtr->numero);
        sPtr = sPtr->nextPtr;
    }
    printf("--> NULL\n");
}

void stampaListaIndietro(ListaPtr sPtr){
    if(sPtr == NULL){
        return;
    }
    stampaListaIndietro(sPtr->nextPtr);
    printf("--> %d ", sPtr->numero);
}

void liberaLista(ListaPtr* sPtr) {
    while (*sPtr != NULL) {
        ListaPtr temp = *sPtr;
        *sPtr = (*sPtr)->nextPtr;
        free(temp);
    }
}