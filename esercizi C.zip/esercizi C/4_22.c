/*modificate il programma della figura 4.5 in modo che calcoli la media dei voti per una classe*/
#include <stdio.h>

int main(){
    int totaleA = 0;
    int totaleB = 0;
    int totaleC = 0;
    int totaleD = 0;
    int totaleF = 0;
    int i =0;
    double media=0;

    printf("inserisci la lettera del voto.\n");
    printf("inserisci EOF per terminare.\n");
    int voto = 0;

    while((voto = getchar()) != EOF){
        switch (voto)
        {
        case 'A':
        case 'a':
            ++totaleA;
            i++;
            break;

        case 'B':
        case 'b':
            ++totaleB;
            i++;
            break;

        case 'C':
        case 'c':
            ++totaleC;
            i++;
            break;
            
        case 'D':
        case 'd':
            ++totaleD;
            i++;
            break;

        case 'F':
        case 'f':
            ++totaleF;
            i++;
            break;

        case '\n':
        case '\t':
        case ' ':
            break;

        default:
            printf("inserita una lettera errata per indicare il voto\n");
            printf("inserisci un nuovo voto.\n");
            break;
        }
    }

    printf("\nil totale per ogni voto e':\n");
    printf("A: %d\n", totaleA);
    printf("B: %d\n", totaleB);
    printf("C: %d\n", totaleC);
    printf("D: %d\n", totaleD);
    printf("F: %d\n", totaleF);
    
    media = (double)(totaleA*10 + totaleB*8 + totaleC*6 + totaleD*4 + totaleF*2) / (double)i;

    if(media > 8)
    printf("la media e' A");
    else if(media > 6)
    printf("la media e' B");
    else if(media > 4)
    printf("la media e' C");
    else if(media > 2)
    printf("la media e' D");
    else
    printf("la media e' F");
}