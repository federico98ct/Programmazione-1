/*scrivete una funzione distance che calcoli la distanza tra due punti(x1, y1) e (x2, y2). tutti i numeri e i valori di ritorno devono essere di tipo double*/
#include <stdio.h>
#include <math.h>

double distance(double x1, double y1, double x2, double y2);

int main(){
    double x1, y1;
    double x2, y2;

    printf("inserisci i valori del primo punto(x, y): ");
    scanf("%lf%lf", &x1, &y1);

    printf("inserisci i valori del secondo punto(x, y): ");
    scanf("%lf%lf", &x2, &y2);

    printf("la distanza tra (%.2f, %.2f) e (%.2f, %.2f) e': %.2f\n", x1, y1, x2, y2, distance(x1, y1, x2, y2));
}

double distance(double x1, double y1, double x2, double y2){
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}