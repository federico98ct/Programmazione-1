/*riscrivete il programma della figura 4.2 per definire e inizializzare la variabile counter prima dell'istruzione for, quindi
stampate il valore di counter dopo il termine del ciclo. */
#include <stdio.h>

int main(){
    int counter = 1;

    for (; counter <= 5; counter++)
    {

    }
    printf("%d ", counter);
    
}