/*modificate la funzione realizzata nell'esercizio precedente per formare il quadrato con qualsiasi carattere contenuto nel 
parametro fillCharacter di tipo char.*/
#include <stdio.h>

void stampaQuadrato(int lato, char segno);

int main(){
    int lato = 0;
    char segno;

    printf("inserisci il valore del lato e il carattere desiderato: ");
    if(scanf("%d %c", &lato, &segno) == 2 && lato > 0){
        stampaQuadrato(lato, segno);
    }
    else{
        printf("inserisci un valore valido");
    }
}

void stampaQuadrato (int lato, char segno){
    for(int i = 1; i <= lato; i++){
        for(int j = 1; j<= lato; j++){
            printf("%c", segno);
        }
        puts("");
    }
}