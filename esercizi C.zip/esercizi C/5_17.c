/*scrivete una funzione isMultiple che determini per una coppia di interi se il secondo intero sia un multiplo del primo. la funzione
deve ricevere due argomenti interi e restituire 1(vero) se il secondo è un multiplo del primo e 0 (falso) nel caso contrario. 
usate questa funzione in un programma che riceve in ingresso una serie di coppie di interi */
#include <stdio.h>

int isMultiple(int x, int y);

int main(){
    int numero1 = 0;
    int numero2 = 0;

    for(int i = 1; i <= 10; i++){
        printf("inserisci una coppia di numeri per determinare se il secondo e' multiplo del primo: ");
        if(scanf("%d%d", &numero1, &numero2) == 2){
            if(isMultiple(numero1, numero2)){
                printf("il numero %d e' multiplo di %d", numero2, numero1);
            }
            else
                printf("il numero %d non e' multiplo di %d", numero2, numero1); 
        }
        else{
            printf("inserisci dei valori validi\n");
            break;
        }
         puts("");
    }
}

int isMultiple(int numero1, int numero2){
    return numero2 % numero1 == 0;
}