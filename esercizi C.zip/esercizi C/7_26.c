/*realizzate un programma guidato da menù che permetta all'utente di scegliere se sommare, sottrarre, moltiplicare o dividere due numeri.
il programma deve quindi leggere due valori double forniti dall'utente, effettuare il calcolo appropriato e stampare il risultato. 
usate un array di puntatori a funzioni che restituisce void e riceve due parametri double. le funzioni corrispondenti devono
ognuna stampare un messaggio che indica quale calcolo è stato eseguito, i valori dei parametri e il risultato del calcolo*/
#include <stdio.h>

void somma(double x, double y);
void sottrazione(double x, double y);
void moltiplicazione(double x, double y);
void divisione(double x, double y);

int main(){
    void (*operazione[4])(double, double) = {somma, sottrazione, moltiplicazione, divisione};
    double x, y;

    printf("%s\n%s\n%s\n%s\n\n",
        " 0 somma",
        " 1 sottrazione",
        " 2 moltiplicazione",
        " 3 divisione");

    printf("inserisci due numeri: ");
    scanf("%lf%lf", &x, &y);

    int choice = 0;
    printf("inserisci l'operazione da esegire: ");
    scanf("%d", &choice);

    (*operazione[choice])(x, y);
}

void somma(double x, double y){
    printf("eseguiamo la somma\n");
    printf("%.2f + %.2f = %.2f", x, y, x + y);
}

void sottrazione(double x, double y){
    printf("eseguiamo la sottrazione\n");
    printf("%.2f - %.2f = %.2f", x, y, x - y);
}

void moltiplicazione(double x, double y){
    printf("eseguiamo la moltiplicazione\n");
    printf("%.2f * %.2f = %.2f", x, y, x * y);
}

void divisione(double x, double y){
    if(y != 0){
        printf("eseguiamo la divisione\n");
        printf("%.2f / %.2f = %.2f", x, y, x / y);
    }
    else printf("errore\n");
}

