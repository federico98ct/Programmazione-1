/*un'applicazione della funzione floor è l'arrotondamento di un valore all'interno più vicino. l'istruzione y = floor(x + .5);
arrotonda il numero x all'intero più vicino e assegna il risultato a y. scrivete un programma che legga diversi numeri e arrotondi
ciascuno di essi all'intero più vicino . per ogni numero processato stampate sia il numero originario che il numero arrotondato. */
#include <stdio.h>
#include <math.h>

int main(){

    double x = 0;

    while (x != -1)
    {
    printf("inserisci un numero da arrotondare: ");
    scanf("%lf", &x);

    printf("%.1f ---> %.0f\n", x, floor(x + .5));
    }
}
