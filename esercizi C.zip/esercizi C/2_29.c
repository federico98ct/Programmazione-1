/*scrivete un programma che riceva in ingresso tre diversi numeri dall'utente. stampate i numeri in ordine crescente.
verificate che il vostro script funzioni eseguendolo su tutti e sei i possibili ordinamenti dei tre numeri.*/

#include <stdio.h>

int main()
{
    int numero1= 0;
    int numero2= 0;
    int numero3= 0;

    printf("inserite tre numeri: ");
    scanf("%d %d %d", &numero1, &numero2, &numero3);

    if(numero1 >= numero2 && numero2 >= numero3){
        printf("%d %d %d\n", numero1, numero2, numero3);
        return 0;
    }
    if(numero1 >= numero3 && numero3 >= numero2){
        printf("%d %d %d\n", numero1, numero3, numero2);
        return 0;
    }
    if(numero3 >= numero1 && numero1 >= numero2){
        printf("%d %d %d\n", numero3, numero1, numero2);
        return 0;
    }
    if(numero3 >= numero2 && numero2 >= numero1){
        printf("%d %d %d\n", numero3, numero2, numero1);
        return 0;
    }
    if(numero2 >= numero3 && numero3 >= numero1){
        printf("%d %d %d\n", numero2, numero3, numero1);
        return 0;
    }
    if(numero2 >= numero1 && numero1 >= numero3){
        printf("%d %d %d\n", numero2, numero1, numero3);
        return 0;
    }
}