/*considerate un'array intero t di dimensioni 2 per 5*/

#include <stdio.h>

int main(){
    //a) scrivete una definizione per t
    //int t [2][5] = {(1,2,3,4,5), (6,7,8,9,10)};

   //b) quante righe ha t? ---> 2
   //c) quante colonne ha t? ---> 5
   //d) quanti elementi ha t? ---> 2 x 5 = 10 elementi

   //e) scrivete i nomi di tutti gli elementi nella seconda riga di t ---> {(1,0);(1,1);(1,2);(1,3);(1,4)}
   //f) scrivete i nomi di tutti gli elementi nella terza colonna di t ---> {(0,2);(1,2)}

   //g) scrivete un'istruzione singola che imposti a 0 l'elemento di t nella riga 1 e nella colonna 2
   //t[1][2] = 0;

   //h) scrivete una serie di istruzioni che inizializzano a 0 ogni elemento di t. non usate un'istruzione di iterazione
   int t[2][5] = {0};

   //i) scrivete un'istruzione for annidata che inizializzi a 0 ogni elemento di t
   for(size_t x = 0; x < 2; x++){
    for(size_t y = 0; y < 5; y++){
        t[x][y] = 0;
    }
   }

   //j) scrivete un'istruzione che faccia inserire i valori per gli elementi di t dal terminale
   for(size_t x = 0; x < 2; x++){
    for(size_t y = 0; y < 5; y++){
        printf("inserisci un valore per [%zu][%zu]: ", x,y);
        scanf("%d", &t[x][y]);
    }
   }

   //k) scrivete una serie di istruzioni che determinino e stampino il valore più piccolo nell'array t
   int maggiore = t[0][0];
   int minore = t[0][0];

   for(size_t x = 0; x < 2; x++){
    for(size_t y = 0; y < 5; y++){
        if(t[x][y] > maggiore){
            maggiore = t[x][y];
        }
        if(t[x][y] < minore){
            minore = t[x][y];
        }
    }
   }

   printf("maggiore: %d\nminore: %d\n", maggiore, minore);

   //l) scrivete un'istruzione che stampi gli elementi della prima riga di t
   
    for(size_t y = 0; y < 5; y++){
        printf("[%zu][%zu] = %d ", 0, y, t[0][y]);
    }

    puts("");

    //m) scrivete un'istruzione che sommi gli element della quarta colonna di t
    for(size_t x = 0; x < 2; x++){
        printf("[%zu][%zu] = %d ", x, 3, t[x][3]);
    }

    puts("");

    //n) scrivete una serie di istruzioni che stampino l'array t in formato tabellare. elencate gli indici di colonna come intestazioni
    //al di sopra delle rispettive colonne ed elencate gli indici di riga alla sinsitra delle rispettive righe
    printf("   ");
    for(size_t x = 0; x < 5; x++){
        printf("%6zu", x);
    }

    puts("\n------------------------------------");

    for(size_t x = 0; x < 2; x++){
        printf("%zu  |", x);
        for(size_t y = 0; y < 5; y++){
            printf("%5d ", t[x][y]);
        }
        puts("");
   }

}