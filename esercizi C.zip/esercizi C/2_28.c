/*la formula per calcolare la vostra massima frequenza cardiaca in battiti al minuto è 220 meno la vostra età.
la frequenza cardiaca ideale durante l'allenamento dovrebbe essere il 50-85% della massima frequenza cardiaca.
scrivete un programma che richieda e legga l'età dell'utente e poi calcoli e visualizzi la massima cardiaca dell'utente 
e l'intervallo della frequenza cardiaca ideale dell'utente */

#include <stdio.h>

int main()
{
    int eta= 0;
    printf("inserite la vostra eta': ");
    scanf("%d", &eta);

    float frequenzaMassima= 220 - eta;
    float frequenzaIm= frequenzaMassima*50/100;
    float frequenzaIM= frequenzaMassima*85/100;

    printf("la frequenza cardiaca massima e': %.0f bpm\n", frequenzaMassima);
    printf("la frequenza cardiaca ideale e' tra %.2f bpm e %.2f bpm", frequenzaIm, frequenzaIM);
}