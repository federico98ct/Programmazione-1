/*scrivete un programma che legga un numero intero di cinque cifre e determini se sia o meno un palindromo */
#include <stdio.h>

int main(){
    int numero =0;
    int numero2 =0;
    int modulo =0;
    int temporaneo = 0;
    
     
        printf("inserisci un numero intero (5 cifre): ");
        scanf("%d", &numero);

        if(numero >= 10000 && numero <= 99999){
            temporaneo = numero;
            while (temporaneo > 0 )
            {
                modulo = temporaneo%10;
                numero2 = numero2 * 10 + modulo;
                temporaneo /=10;
            }  
        }
        else{
           printf("inserisci un numero valido, ricorda che deve avere 5 cifre.\n");
           return 1;
        }
    printf("numero 1:%d\n", numero);
    printf("numero 2:%d\n", numero2);

    if (numero == numero2)
    {
        printf("il numero e' palindromo");
    }
    else
        printf("il numero non e' palindromo");
}