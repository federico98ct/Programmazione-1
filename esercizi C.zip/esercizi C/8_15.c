/*(stampa di una frase all'inverso) scrivete un programma che legga una riga di testo, la spezzi in token con la funzione strtok
e invii in uscita i token in ordine inverso*/
#include <stdio.h>
#include <string.h>

#define SIZE 100

int main(){
    char riga[SIZE] = "";
    char *rigaInversa[SIZE] = {};
    int i = 0;

    printf("inserisci una riga di testo: ");
    fgets(riga, SIZE, stdin);
    if(strlen(riga) > 0) riga[strlen(riga) - 1] = '\0';

    char *ptr = strtok(riga, " ");
    rigaInversa[i] = ptr;
    
    while((ptr = strtok(NULL, " ")) != NULL){
        i++;
        rigaInversa[i] = ptr;
    }
    
    for (; i >= 0; i--){
        printf("%s ", rigaInversa[i]);
    }
    
}