/*scrivete un programma che legga diverse righe di testo e un carattere da ricercare e che usi la funzione strchr per determinare
il totale delle volte in cui il carattere compare nelle righe di testo*/
#include <stdio.h>
#include <string.h>

#define SIZE 100
#define MAX_RIGHE 10

void chiediStringa(char stringa[]);

int main(){
    char righe[MAX_RIGHE][SIZE];
    char carattere;
    int nRighe, i, occorrenze = 0;

    printf("inserisci quante righe vuoi inserire (max 10): "); //chiedi quannte righe si vogliono inserire
    scanf("%d", &nRighe);
    getchar(); //pulizia buffer

    if(nRighe > MAX_RIGHE || nRighe < 1){ 
        printf("valore di righe non valido\n");
        return 1;
    }

    for ( i = 0; i < nRighe; i++) //inserimento stringhe
    {
        printf("inserisci stringa %d: ", i+1);
        chiediStringa(righe[i]);
    }

    printf("inserisci il carattere da ricercare: ");
    carattere = getchar();
    getchar(); //pulizia buffer

    for (i = 0; i < nRighe; i++){ //controlla le occorrenze
        char *ptr = strchr(righe[i], carattere);
        while(ptr != NULL){
            occorrenze++;
            ptr = strchr(ptr + 1, carattere);
        }

    }
    
    printf("il carattere \"%c\" ricorre \"%d\" volte nelle righe di testo\n", carattere, occorrenze);

}

void chiediStringa(char stringa[]){
    fgets(stringa, SIZE, stdin);
    stringa[strcspn(stringa, "\n")] = '\0';
}