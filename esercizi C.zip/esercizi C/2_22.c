/*scrivete un programma che legga un intero e determini e stampi se sia pari o dispari. usate l'operatore di resto.*/

#include <stdio.h>

int main()
{
    int numero =0;
    printf("inserisci un numero: ");
    scanf("%d", &numero);

    int resto = numero % 2;

    if(resto == 0)
        printf("il numero e' pari");
    
    if(resto != 0)
        printf("il numero e' dispari");
}