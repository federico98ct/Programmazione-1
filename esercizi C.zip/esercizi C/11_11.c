/*(inventario di ferramenta) siete i proprietari di un negozio di ferramenta e avete necessità di tenere un inventario che possa
dirvi quali attrezzi avete, quanti ne avete e il costo di ognuno di essi. scrivete un programma che inizializzi il file "hardware.dat"
con 100 record vuoti, vi faccia inserire i dati riguardanti ogni attrezzo , vi consenta di fare una lista di tutti i vostri attrezzi,
vi faccia cancellare un record relativo a un attrezzo che non avete più e vi faccia aggiornare una qualunque informazione nel file.
il numero di identificazione dell'attrezzo deve essere il numero del record.*/
#include <stdio.h>
#include <string.h>

typedef struct {
    int chiave;
    char nome[30];
    int quantita;
    double costo;
} Attrezzo;

int stampaScelte();
void creaFile();
void inserisciArticoli();
void stampaLista();
void cancella();
void aggiorna();

int main() {
    printf("**benvenuto nel programma di gestione inventario!**\n");

    int scelta;
    while((scelta = stampaScelte()) != 6) {
        switch(scelta) {
            case 1: creaFile(); break;
            case 2: inserisciArticoli(); break;
            case 3: stampaLista(); break;
            case 4: cancella(); break;
            case 5: aggiorna(); break;
            default:
                while(getchar() != '\n');
                printf("valore non valido!\n");
                break;
        }
    }
}

void creaFile() {
    FILE *fPtr = fopen("hardware.dat", "wb");
    if(fPtr == NULL) {
        printf("Impossibile creare il file!\n");
        return;
    }

    Attrezzo attrezzo = {0, "vuoto", 0, 0.0};
    for(size_t i = 0; i < 100; i++) {
        fwrite(&attrezzo, sizeof(Attrezzo), 1, fPtr);
    }
    fclose(fPtr);
}

void inserisciArticoli() {
    FILE *ptr = fopen("hardware.dat", "rb+");
    if(ptr == NULL) {
        printf("File non trovato o non apribile in scrittura.\n");
        return;
    }

    Attrezzo articolo;
    char continua = 's';

    while (continua == 's' || continua == 'S') {
        printf("Inserisci il nome dell'articolo:\n");
        fgets(articolo.nome, sizeof(articolo.nome), stdin);
        articolo.nome[strcspn(articolo.nome, "\n")] = '\0';

        printf("Inserisci il codice (0-99), la quantita' e il costo:\n");
        if (scanf("%d %d %lf", &articolo.chiave, &articolo.quantita, &articolo.costo) != 3 ||
            articolo.chiave < 0 || articolo.chiave > 99) {
            printf("Valori non validi! Inserimento annullato.\n");
            while (getchar() != '\n');
            continue;
        }

        fseek(ptr, sizeof(Attrezzo) * articolo.chiave, SEEK_SET);
        fwrite(&articolo, sizeof(Attrezzo), 1, ptr);
        printf("Articolo salvato nella posizione %d.\n", articolo.chiave);

        while (getchar() != '\n');
        printf("Vuoi inserire un altro articolo? (s/n): ");
        scanf(" %c", &continua);
    }

    fclose(ptr);
}

void stampaLista() {
    FILE *bptr = fopen("hardware.dat", "rb");
    FILE *tptr = fopen("hardware.txt", "w+");
    if (bptr == NULL || tptr == NULL) {
        printf("File non trovati o non apribili in scrittura.\n");
        return;
    }

    Attrezzo temp;
    fprintf(tptr, "%-6s %-20s %-10s %10s\n", "codice", "nome", "quantita'", "costo");
    while (fread(&temp, sizeof(Attrezzo), 1, bptr) == 1) {
        if (strcmp(temp.nome, "vuoto") != 0) {
            fprintf(tptr, "%-6d %-30s %-10d %10.2f\n", temp.chiave, temp.nome, temp.quantita, temp.costo);
        }
    }

    printf("lista stampata correttamente!\n");
    fclose(bptr);
    fclose(tptr);
}

void cancella() {
    FILE *ptr = fopen("hardware.dat", "rb+");
    if(ptr == NULL) {
        printf("Impossibile creare il file!\n");
        return;
    }

    Attrezzo vuoto = {0, "vuoto", 0, 0.0}, letto;
    int scelta = 0, ok = 0;
    char continuare = 's';

    while (continuare == 's' || continuare == 'S') {
        printf("inserisci articolo da eliminare: ");
        if(scanf("%d", &scelta) != 1 || scelta < 0 || scelta >= 100) {
            printf("dato non valido!\n");
            while(getchar() != '\n');
            continue;
        }

        fseek(ptr, sizeof(Attrezzo) * scelta, SEEK_SET);
        fread(&letto, sizeof(Attrezzo), 1, ptr);
        if(strcmp(letto.nome, "vuoto") == 0) {
            printf("articolo già vuoto.\n");
        } else {
            fseek(ptr, sizeof(Attrezzo) * scelta, SEEK_SET);
            fwrite(&vuoto, sizeof(Attrezzo), 1, ptr);
            printf("articolo eliminato correttamente!\n");
            ok = 1;
        }

        while(getchar() != '\n');
        printf("vuoi eliminare un altro articolo?(s/n): ");
        scanf(" %c", &continuare);
    }

    if(!ok) {
        printf("nessuna eliminazione effettuata.\n");
    }

    fclose(ptr);
}

void aggiorna() {
    FILE *ptr = fopen("hardware.dat", "rb+");
    if(ptr == NULL) {
        printf("Impossibile creare il file!\n");
        return;
    }

    Attrezzo temp;
    int scelta;
    char continuare = 's';

    while(continuare == 's' || continuare == 'S') {
        printf("inserisci articolo che vuoi aggiornare: ");
        if(scanf("%d", &scelta) != 1 || scelta < 0 || scelta > 99) {
            printf("valore non valido!\n");
            while(getchar() != '\n');
            continue;
        }

        fseek(ptr, sizeof(Attrezzo) * scelta, SEEK_SET);
        fread(&temp, sizeof(Attrezzo), 1, ptr);

        if (strcmp(temp.nome, "vuoto") == 0) {
            printf("Nessun articolo presente in questa posizione.\n");
        } else {
            printf("Articolo attuale: %s, quantita': %d, costo: %.2f\n",
                   temp.nome, temp.quantita, temp.costo);
            printf("cosa si vuole modificare?(1-nome, 2-quantita', 3-costo): ");
            int choice = 0;
            if(scanf("%d", &choice) != 1 || choice < 1 || choice > 3) {
                printf("valore non valido!\n");
                while(getchar() != '\n');
                continue;
            }

            while(getchar() != '\n'); // pulizia prima di eventuale fgets

            switch (choice) {
                case 1:
                    printf("inserisci nuovo nome: ");
                    fgets(temp.nome, sizeof(temp.nome), stdin);
                    temp.nome[strcspn(temp.nome, "\n")] = '\0';
                    break;
                case 2:
                    printf("inserisci nuova quantita': ");
                    scanf("%d", &temp.quantita);
                    break;
                case 3:
                    printf("inserisci nuovo prezzo: ");
                    scanf("%lf", &temp.costo);
                    break;
            }

            fseek(ptr, sizeof(Attrezzo) * scelta, SEEK_SET);
            fwrite(&temp, sizeof(Attrezzo), 1, ptr);
            printf("Articolo aggiornato.\n");
        }

        printf("vuoi aggiornare un altro articolo?(s/n): ");
        scanf(" %c", &continuare);
    }

    fclose(ptr);
}

int stampaScelte() {
    printf("%s\n%s\n%s\n%s\n%s\n%s",
        "1 - Crea un file",
        "2 - Inserisci articoli",
        "3 - Stampa lista di tutti gli articoli",
        "4 - Cancella dato specifico",
        "5 - Aggiorna dato specifico",
        "6 - Esci");

    printf("\ninserisci una scelta: ");
    int choice;
    scanf("%d", &choice);
    while(getchar() != '\n');
    return choice;
}