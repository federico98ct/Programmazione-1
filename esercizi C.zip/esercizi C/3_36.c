/*scrivete un programma che con un ciclo while che conti da 1 a 1.000.000.000 per incrementi di 1. ogni volta che il conto 
raggiunge un multiplo di 100.000.000, stampate quel numero sullo schermo*/
#include <stdio.h>

int main(){
    int contatore =1;
    while (contatore <= 1000000000)
    {
        if (contatore%100000000 == 0)
        {
            printf("%d\n",contatore);
        }
        
        contatore++;
    }  
}