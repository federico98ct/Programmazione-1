/*(inserimento in una lista ordinata) scrivete un programma che inserisca a caso 25 interi da 0 a 100 in ordine in una lista collegata
il programma deve calcolare la somma degli elementi e la loro media in virgola mobile*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct lista{
    int numero;
    struct lista* nextPtr;
};

typedef struct lista Lista;
typedef Lista* ListaPtr;

void insert(ListaPtr* sPtr, int n);
void stampaLista(ListaPtr sPtr);
void distruggiLista(ListaPtr* sPtr);

int main(){
    int numero;
    srand(time(NULL));

    ListaPtr startPtr = NULL;
    
    int somma = 0;
    for(size_t i = 0; i < 25; i++){
        numero = rand() %101;
        somma += numero;
        insert(&startPtr, numero); 
    }

    stampaLista(startPtr);
    printf("la somma e': %d\n", somma);
    printf("la media e': %.2f\n", (double)somma/25);
    distruggiLista(&startPtr);

}

void insert(ListaPtr* sPtr, int n){
    ListaPtr newPtr = malloc(sizeof(Lista));

    if(newPtr != NULL){
        newPtr->numero = n;
        newPtr->nextPtr = NULL;

        ListaPtr previousPtr = NULL;
        ListaPtr currentPtr = *sPtr;

        while(currentPtr != NULL && n > currentPtr->numero){
            previousPtr = currentPtr;
            currentPtr = currentPtr->nextPtr;
        }
        if(previousPtr == NULL){
            newPtr->nextPtr = *sPtr;
            *sPtr = newPtr;
        }
        else{
            previousPtr->nextPtr = newPtr;
            newPtr->nextPtr = currentPtr;
        }
    }
    else{
        printf("memoria esaurita\n");
    }
}

void stampaLista(ListaPtr sPtr){
    if(sPtr == NULL){
        printf("la lista e' vuota\n");
        return;
    }
    while(sPtr != NULL){
        printf("--> %d ", sPtr->numero);
        sPtr = sPtr->nextPtr;
    }
    printf("--> NULL\n");
}

void distruggiLista(ListaPtr* sPtr){
    while(*sPtr != NULL){
        ListaPtr temp = *sPtr;
        *sPtr = (*sPtr)->nextPtr;
        free(temp);
    }
}
