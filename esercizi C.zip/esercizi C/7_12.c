#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define SEMI 4
#define FACCE 13
#define CARTE 52
#define MANO 5

void mischia(int mazzo[][FACCE]);
void distribuisci(int mazzo[][FACCE], const char *faccia[], const char *seme[], char *manoF[], char *manoS[], int *cartaDistribuita);
void coppie(const char *manoF[], int *punti);
void colore(const char *manoS[], int *punti);
void scala(const char *manoF[], const char *faccia[], int *punti);
void ordinaMano(int mano[]);
void punteggio(int punteggio1, int punteggio2);

int main(){
    int mazzo[SEMI][FACCE] = {0};   //mazzo generale
    int cartaDIstribuita = 1;       //contatore delle carte già date

    int punti1 = 0;                 //prima mano
    char *manoF1[MANO];             
    char *manoS1[MANO];             

    int punti2 = 0;                 //seconda mano
    char *manoF2[MANO]; 
    char *manoS2[MANO]; 

    srand(time(NULL));
    mischia(mazzo);                 //mischia il mazzo

    const char *seme [SEMI] = {"Cuori", "Quadri", "Fiori", "Picche"};
    const char *faccia [FACCE] = {"Asso", "Due", "Tre", "Quattro", "Cinque", 
        "Sei", "Sette", "Otto", "Nove", "Dieci", "Jack", "Regina", "Re"};

    printf("mazzo 1: \n");
    distribuisci(mazzo, faccia, seme, manoF1, manoS1, &cartaDIstribuita); //distribuisci carte primo mazzo
    printf("mazzo 2: \n");
    distribuisci(mazzo, faccia, seme, manoF2, manoS2, &cartaDIstribuita); //distribuisci carte secondo mazzo
    printf("---------------------------------------------------------------------------------------------------------------------\n");
    printf("GIOCATE primo mazzo: "); //riepilogo giocate primo mazzo
    coppie(manoF1, &punti1);
    colore(manoS1, &punti1);
    scala(manoF1, faccia, &punti1);
    printf("punti: %d\n", punti1);
    
    puts("");

    printf("GIOCATE seconso mazzo: "); //riepilogo giocate secondo mazzo
    coppie(manoF2, &punti2);
    colore(manoS2, &punti2);
    scala(manoF2, faccia, &punti2);
    printf("punti: %d\n", punti2);

    punteggio(punti1, punti2);

}

void mischia(int mazzo[][FACCE]){
    for(size_t carta = 1; carta <= CARTE; carta ++){

        size_t riga = 0;
        size_t colonna = 0;

        do{
            riga = rand() % SEMI;
            colonna = rand() % FACCE;
        } while (mazzo[riga][colonna] != 0);

        mazzo[riga][colonna] = carta;  
    }
}

void distribuisci(int mazzo[][FACCE], const char *faccia[], const char *seme[], char *manoF[], char *manoS[], int *cartaDistribuita){

    
    size_t i = 0;

    for(size_t carta = 1; carta <= MANO; carta++){
        int cartaTrovata = 0;
        for(size_t riga = 0; riga < SEMI && cartaTrovata != 1; riga++){
            for(size_t colonna = 0; colonna < FACCE && cartaTrovata != 1; colonna++){
                if(mazzo[riga][colonna] == *cartaDistribuita){
                    cartaTrovata = 1;
                    (*cartaDistribuita)++;

                    manoF[i] = (char *)faccia[colonna]; 
                    manoS[i] = (char *)seme[riga];

                    i++;
                    
                    printf("%8s di %-8s \t", faccia[colonna], seme[riga]);
                }
            }
        }
    }
    puts("");
    
}

void coppie(const char *manoF[], int *punti){
    int coppia = 0;
    for (size_t x = 0; x < MANO -1; x++){
        for (size_t y = x + 1; y < MANO; y++){
            if(strcmp(manoF[x], manoF[y]) == 0){ 
                coppia++;
            }
        }   
    }
  
    switch (coppia)
    {
    case 1:
        printf("e' presente una coppia\n");
        (*punti) += 1;
        break;
    case 2:
        printf("e' presente una doppia coppia\n");
        (*punti) += 2;
        break;
    case 3:
        printf("e' presente un tris\n");
        (*punti) += 3;
        break;
    case 4:
        printf("e' presente un poker\n");
        (*punti) += 5;
        break;
    case 5: 
        printf("e' presente un full(coppia + tris)\n");
        (*punti) += 4;
        break;
    default:
        printf("nessuna\n");
        break;
    }
}

void colore(const char *manoS[], int *punti){
    int colore= 0;
    for (size_t i = 0; i < MANO - 1; i++)
    {
        if(manoS[0] == manoS[i]){
            colore++;
        }
    }
    if(colore == 5){
        printf("hai fatto colore\n");
        (*punti) += 6;
    }
}

void scala(const char *manoF[], const char *faccia[], int *punti){
    int array_temp[MANO] = {0};
    for (size_t carta = 0; carta < MANO; carta++){
        for (size_t ordine = 0; ordine < FACCE; ordine++)
        {
            if(manoF[carta] == faccia[ordine]){
                array_temp[carta] = ordine;
            }
        }
    }
    ordinaMano(array_temp);

    int scala = 1;
    for (size_t i = 0; i < MANO - 1; i++){
        if(array_temp[i] + 1 != array_temp[i + 1]){
            scala = 0;
            break;
        }
    }
    if(scala){
        printf("hai fatto scala\n");
        (*punti) += 7;
    }
    
}

void ordinaMano(int mano[]){
    
    for (size_t x = 0; x < MANO - 1; x++){
        for (size_t y = 0; y < MANO - 1; y++){
            if(mano[y] > mano[y + 1]){
                int temp =mano[y];
                mano[y] = mano[y + 1];
                mano[y + 1] = temp;
            }   
        }
    }
}

void punteggio(int punti1, int punti2){
    if(punti1 > punti2) printf("ha vinto mazzo 1\n");
    else if(punti1 < punti2) printf("ha vinto mazzo 2\n");
    else printf("pareggio\n");
}



