/*scrivete un programma che legga due interi inseriti dall'utente, 
quindi ne stampi la somma, il prodotto, la differenza, il quoziente e il resto*/
#include <stdio.h>

int main()
{
    int numero1 = 0;
    int numero2 = 0;

    printf("inserisci due numeri: ");
    scanf("%d %d", &numero1, &numero2);

    int somma = numero1 + numero2;
    int prodotto = numero1 * numero2;
    int differenza = numero1 - numero2;
    int divisione = numero1 / numero2;
    int resto = numero1 % numero2;

    printf("\nla somma e': \t\t%d\n", somma);
    printf("il prodotto e': \t%d\n", prodotto);
    printf("la differenza e': \t%d\n", differenza);
    printf("la divisione e': \t%d\n", divisione);
    printf("il resto e': \t\t%d\n", resto);
}