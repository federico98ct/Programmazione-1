/*scrivete un programma che calcoli il valore di e^x*/
#include <stdio.h>

int main(){
    double x= 0;
    double e= 1;
    double fattoriale= 1;
    double i= 1;
    double potenza =1;

    printf("inserisci un valore di x: ");
    scanf("%lf", &x);

    while (i < 10)
    {
        potenza *= x;
        fattoriale *= i;
        e += potenza/fattoriale;
        i++;
        printf("%.20f\n", e);
    }
    printf("%.15f", e);
}