/*scrivete un'istruzione o un'insieme di istruzioni per eseguire ognuna delle seguenti operazioni.*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct gradeNode{
    char cognome[20];
    double voto;
    struct gradeNode* nextptr;
};

typedef struct gradeNode GradeNode;
typedef GradeNode* GradeNodePtr;

void inserimentoNodi(GradeNodePtr *sPtr, char cognome[], double voto);
void stampaLista(GradeNodePtr sPtr);
void cancellaLista(GradeNodePtr *sptr);

int main(){
    GradeNodePtr startPtr = NULL;
    char cognome[20] = {};
    double voto;

    printf("**benvenuto nel programma di inserimento voti!**\n");
    printf("prego inserire cognome e votazione: ");
    scanf("%19s %lf", cognome, &voto);
    
    while(voto != -1){
        inserimentoNodi(&startPtr, cognome, voto);
        printf("prego inserire cognome e votazione: ");
        scanf("%19s %lf", cognome, &voto);
    }
    stampaLista(startPtr);
    cancellaLista(&startPtr);
    stampaLista(startPtr);
}

void inserimentoNodi(GradeNodePtr *sPtr, char cognome[], double voto){
    GradeNodePtr newPtr = malloc(sizeof(GradeNode)); //crea il nodo

    if(newPtr != NULL){
        strcpy(newPtr->cognome, cognome);
        newPtr->voto = voto;
        newPtr->nextptr = NULL;

        GradeNodePtr previousPtr = NULL;
        GradeNodePtr currentPtr = *sPtr;

        while(currentPtr != NULL && strcasecmp(cognome, currentPtr->cognome) > 0){ //trova la posizione corretta in cui inserire il nodo
            previousPtr = currentPtr;
            currentPtr = currentPtr->nextptr;
        }

        if(previousPtr == NULL){ //inserisci nuovo nodo all'inizio della lista
            newPtr->nextptr = *sPtr;
            *sPtr = newPtr;
        }
        else{ //inserisci nuovo nodo tra previousPtr e currentPtr
            previousPtr->nextptr = newPtr;
            newPtr->nextptr = currentPtr;
        }
    }
    else{
        printf("nessuna memoria disponibile\n");
    }
}

void stampaLista(GradeNodePtr sPtr){
    if(sPtr == NULL){
        printf("la lista e' vuota\n");
    }
    while(sPtr != NULL) {
        printf("Cognome: %-20s | Voto: %.1f\n", sPtr->cognome, sPtr->voto);
        sPtr = sPtr->nextptr;
    }
}

void cancellaLista(GradeNodePtr *sptr){
    GradeNodePtr tempPtr = NULL;
    GradeNodePtr currentPtr = *sptr;
    while(currentPtr != NULL){
        tempPtr = currentPtr;
        currentPtr = currentPtr->nextptr;
        free(tempPtr);
    }
    *sptr = NULL;
}

