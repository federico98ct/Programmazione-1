/*modificate il programma dell'esercizio precedente per confrontare il numero delle risposte date dal giocatore. se il numero 
è 10 o di meno, stampate "bravo conosci il segreto o sei stato molto fortunato!". se il giocatore indovina il numero dopo 10 
tentativi, allora stampate "sei in grado di far meglio!".*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void risposte(int risposta, int numero, int i);

int main(){
    int risposta = 0;
    int i = 0;
    char rigiocare = 'y';

    srand(time(NULL));

    do
    {
        int numero = 1 + (rand() % 2);
        printf("sto pensando ad un numero tra 1 e 1000.\n");
        printf("riesci ad indovinarlo?\n");
        i = 0;
        risposta = 0;

        while(numero != risposta){
            printf("inserisci la tua risposta: ");
            if(scanf("%d", &risposta) == 1 && risposta >=1 && risposta <= 1000){
                i += 1;
                risposte(risposta, numero, i);
            }
            else{
                printf("inserisci un numero valido\n");
                while (getchar() != '\n'); 
            }
        }

        printf("vorresti rigiocare (y or n)? ");
        scanf(" %c", &rigiocare);

    } while(rigiocare == 'y');    
}

void risposte(int risposta, int numero, int i){
    
    if(risposta > numero){
        printf("troppo alto. riprova.\n");
    }
    else if(risposta < numero){
        printf("troppo basso. riprova.\n");
    }
    else{
        if(i <= 10 ){
            printf("eccellente! hai indovinato il numero in meno di 10 tentativi!\n");
            printf("conosci il segreto o sei stato molto fortunato!\n");
        }
        else{
            printf("bravo hai indovinato il numero!\n");
            printf("ma sono sicuro che potresti fare di meglio!\n");
        }
    }       
}