/*scrivete un programma che riceva in ingresso una serie di interi e li passi uno alla volta alla funzione isEven, che usa l'operatore 
di resto per determinare se un intero è pari. la funzione deve prendere un argomento intero e restituire 1 se l'intero è pari e 0
nel caso contrario*/
#include <stdio.h>

int isEven(int x);

int main(){
    int numero = 0;
    for(int i = 1; i <= 10; i++){
        printf("inserisci un numero per determinare se e' pari: ");
        if(scanf("%d", &numero) == 1){
            if(isEven(numero)){
                printf("il numero e' pari");
            }
            else
                printf("il numero e' dispari");
        }
        else{
            printf("inserisci un valore corretto");
            while (getchar() != '\n');
            i--;
        }
        puts("");
    }
}

int isEven(int numero){
    return numero % 2 == 0;
}