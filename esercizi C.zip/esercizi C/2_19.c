/*scrivete un programma che riceva in ingresso tre diversi interi dalla tastiera, poi stampi la somma, la media,
il prodotto, il minore e il maggiore di questi numeri. usate solamente la forma a selezione singola dell'istruzione if */

#include <stdio.h>

int main()
{
    int numero1 = 0;
    int numero2 = 0;
    int numero3 = 0;

    printf("inserite tre numeri: ");
    scanf("%d %d %d", &numero1, &numero2, &numero3);

    int somma = numero1 + numero2 + numero3;
    int media = somma/3;
    int prodotto = numero1 * numero2 * numero3;

    printf("la somma e' %d\n", somma);
    printf("la media e' %d\n", media);
    printf("il prodotto e' %d\n", prodotto);

    //per il più grande
    if(numero1 > numero2)
        if(numero1 > numero3)
            printf("il piu' grande e' %d\n", numero1);

    if(numero2 > numero1)
        if(numero2 > numero3)
            printf("il piu' grande e' %d\n", numero2);

    if(numero3 > numero1)
        if(numero3 > numero2)
            printf("il piu' grande e' %d\n", numero3);

    //per il più piccolo
    if(numero1 < numero2)
        if(numero1 < numero3)
            printf("il piu' piccolo e' %d\n", numero1);
    
    if(numero2 < numero1)
        if(numero2 < numero3)
            printf("il piu' piccolo e' %d\n", numero2);
    
    if(numero3 < numero1)
        if(numero3 < numero2)
            printf("il piu' piccolo e' %d\n", numero3);
}