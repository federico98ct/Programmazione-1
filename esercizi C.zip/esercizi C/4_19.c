/*scrivete un programma che legga una serie di coppie di numeri come segue:
a) numero del prodotto
b) quantità venduta in un giorno
il vostro programma deve usare un'istruzione switch per permettervi di determinare il prezzo al dettaglio per ogni prodotto. 
inoltre deve calcolare e stampare il valore al dettaglio totale di tutti i prodotti venduti nell'ultima settimana.*/
#include <stdio.h>

int main(){
    int numero_prodotto, vendite_giorno;
    double totale1 = 0, totale2 = 0, totale3 = 0, totale4 = 0, totale5 =0;

    for(int giorno = 1; giorno <= 7; giorno++){

        printf("giorno %d\n", giorno);

        for(int i =1; i <= 5;){
            printf("inserisci il numero del prodotto: ");
            scanf("%d", &numero_prodotto);

            if(numero_prodotto < 1 || numero_prodotto > 5){
                printf("perfavore inserisci un numero da uno a 5\n");
                continue;
            }
            printf("inserisci la quantita' venduta: ");
            scanf("%d", &vendite_giorno);

            switch (numero_prodotto)
            {
            case 1:
                
                totale1 += (double)vendite_giorno * 2.98;
                break;
            case 2:
                totale2 += (double)vendite_giorno * 4.50;
                break;
            case 3:
                totale3 += (double)vendite_giorno * 9.98;
                break;
            case 4:
                totale4 += (double)vendite_giorno * 4.49;
                break;
            case 5:
                totale5 += (double)vendite_giorno * 6.87;
                break;
            }
            printf("\n");
            i++;
        }
    }
    printf("%s%30s", "numero del prodotto", "totale venite settimanali\n");
    printf("%d%27.2f\n", 1, totale1);
    printf("%d%27.2f\n", 2, totale2);
    printf("%d%27.2f\n", 3, totale3);
    printf("%d%27.2f\n", 4, totale4);
    printf("%d%27.2f\n", 5, totale5);
    
}