/*scrivete un programma che legga 5 numeri (ognuno tra 1 e 30). per ogni numero letto, il vostro programma deve stampare una riga contenente
quel numero di asterischi contigui.*/
#include <stdio.h>

int main(){
    int numero = 1;

    for(int i = 1; i <= 5;){
        printf("inserisci un numero: ");
        scanf("%d", &numero);
        if(numero >= 1 && numero <= 30){

            for(;numero > 0; numero--){
                printf("*");
            }
            printf("\n");
        }
        else{
            printf("inserisci un numero valido\n");
            continue;
        }
        i++;
    }
}