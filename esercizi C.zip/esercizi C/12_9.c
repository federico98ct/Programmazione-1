/*(creare una lista collegata, quindi invertire gli elementi) scrivete un programma che crei una lista collegata di 10 caratteri
e poi crei una copia della lista in ordine inverso*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct lista{
    struct lista* prevPtr;
    char c;
    struct lista* nextPtr;
};

typedef struct lista Lista;
typedef Lista* ListaPtr;

void insert(ListaPtr* sPtr, char c);
void stampaLista(ListaPtr sPtr);
ListaPtr copiaInversa(ListaPtr sptr);
void cancellaLista(ListaPtr* sPtr);

int main(){
    srand(time(NULL));
    char lettera;

    ListaPtr startPtr = NULL;

    for(size_t i = 0; i < 10; i++){
        lettera = 'a' + (rand() % 26);
        insert(&startPtr, lettera);
    }

    printf("\nCopia originale\n");
    stampaLista(startPtr);
    ListaPtr inversa = copiaInversa(startPtr);
    printf("\nCopia inversa:\n");
    stampaLista(inversa);

    cancellaLista(&inversa);
    cancellaLista(&startPtr);    
}

void insert(ListaPtr* sPtr, char c){
    ListaPtr newPtr = malloc(sizeof(Lista));

    if(newPtr != NULL){
        newPtr->c = c;
        newPtr->nextPtr = NULL;
        newPtr->prevPtr = NULL;

        ListaPtr previousPtr = NULL;
        ListaPtr currentPtr = *sPtr;

        while(currentPtr != NULL && c > currentPtr->c){
            previousPtr = currentPtr;
            currentPtr = currentPtr->nextPtr;
        }
        if(previousPtr == NULL){
            newPtr->nextPtr = *sPtr;
            *sPtr = newPtr;
            newPtr->prevPtr = NULL;
            if (currentPtr != NULL) {
                currentPtr->prevPtr = newPtr;
            }
        }
        else{
            previousPtr->nextPtr=newPtr;
            newPtr->nextPtr = currentPtr;
            newPtr->prevPtr = previousPtr;
            if (currentPtr != NULL) {
                currentPtr->prevPtr = newPtr;
            }
        }
    }
    else{
        printf("memoria esaurita\n");
    }
}

void cancellaLista(ListaPtr* sPtr){
    if(*sPtr == NULL){
        printf("la lista e' gia' vuota\n");
    }
    while(*sPtr != NULL){
        ListaPtr temp = *sPtr;
        *sPtr = (*sPtr)->nextPtr;
        free(temp);
    }
}

void stampaLista(ListaPtr sPtr){
    if(sPtr == NULL){
        printf("la lista e' vuota\n");
        return;
    }
    while(sPtr != NULL){
        printf("--> %c", sPtr->c);
        sPtr = sPtr->nextPtr;
    }
    printf("--> NULL\n");
}

ListaPtr copiaInversa(ListaPtr sPtr){
    if (sPtr == NULL) {
        return NULL;
    }

    // Vai all'ultimo nodo della lista originale
    while (sPtr->nextPtr != NULL) {
        sPtr = sPtr->nextPtr;
    }

    ListaPtr testaPtr = NULL;  // Inizio della nuova lista
    ListaPtr previousPtr = NULL;   // Ultimo nodo della nuova lista

    while (sPtr != NULL) {
        ListaPtr newPtr = malloc(sizeof(Lista));
        if (newPtr == NULL) {
            printf("memoria esaurita\n");
            cancellaLista(&testaPtr);
            return NULL;
        }

        newPtr->c = sPtr->c;
        newPtr->nextPtr = NULL;
        newPtr->prevPtr = previousPtr;

        if (previousPtr != NULL) {
            previousPtr->nextPtr = newPtr;
        } else {
            testaPtr = newPtr;  // È il primo nodo inserito
        }

        previousPtr = newPtr;
        sPtr = sPtr->prevPtr;
    }

    return testaPtr;
}
