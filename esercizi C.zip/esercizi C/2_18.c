/*scrivete un programma che legga due interi inseriti dall'utente e quindi stampi il numero maggiore seguito dalle parole
"è più grande". se i numeri sono uguali, stampate il messaggio "questi numeri sono uguali". usate solamente la forma a selezione
singola dell'istruzione if */

#include <stdio.h>

int main() 
{
    int numero1 = 0;
    int numero2 = 0;

    printf("inserisci due numeri: ");
    scanf("%d %d", &numero1, &numero2);

    if(numero1 > numero2)
        printf("%d e' piu' grande", numero1);
    
    if(numero2 > numero1)
        printf("%d e' piu' grande", numero2);
    
    if(numero1 == numero2)
        printf("questi numeri sono uguali");
}