/*modificate il programma dell'interesse composto del paragrafo 4.5 in modo da ripetere i suoi passi per i tassi di interesse
del 5%, 6%, 7%, %8, 9% e 10%. usate un ciclo for per variare il tasso d'interesse*/
#include <stdio.h>
#include <math.h>

int main(){
    double capitale = 1000.0;
    double tasso_interesse = 0.05;

    printf("%-4s%19s%16s%16s%16s%16s%17s\n", "anno", "ammonto 5%", "ammonto 6%", "ammonto 7%", "ammonto 8%", "ammonto 9%", "ammonto 10%");

    for (int anno = 1; anno <= 10; anno++)
    {
        printf("%-4d", anno);

        for(;tasso_interesse <= 0.10; tasso_interesse += 0.01){
            
            double ammonto = capitale * pow(1.0 + tasso_interesse, anno);
            printf("%16.2f", ammonto);
        }
        tasso_interesse = 0.05;
        printf("\n");
    }
    
    
}