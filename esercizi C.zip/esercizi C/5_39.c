/*il massimo comine divisore degli interi x e y è l'intero più grande che divide in parti uguali sia x che y. scrivete una 
funzione ricorsiva gcd che restituisca il massimo comun divisore di x e y*/
#include <stdio.h>

int MCD(int x, int y);

int main(){
    int x = 13;
    int y = 7;

    printf("il MCD tra %d e %d e': %d", x, y, MCD(x, y));
}

int MCD(int x, int y){
    printf("x=%d y=%d\n", x, y);
    if(y == 0) return x;
   
    return MCD(y, x % y);
}