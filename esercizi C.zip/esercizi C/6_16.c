/*etichettate gli elementi dell'array bidimensionale sales 3x5 per indicare l'ordine in cui sono posti a 0 dal seguente 
segmento di programma*/
#include <stdio.h>

int main(){
    int sales[3][5];
    int etichetta = 1;

    for(size_t row = 0; row < 3; ++row){
        for(size_t column = 0; column < 5; ++column){
            sales[row][column] = 0;
            printf("%4d", etichetta++);
        }
        puts("");
    }
}