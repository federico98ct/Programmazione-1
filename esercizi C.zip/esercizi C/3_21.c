/*scrivere un programma che dimostri la differenza tra predecrementare e postdecrementare utilizzando l'operatore di decremento --*/

#include <stdio.h>

int main()
{
    int i = 5;
    int y = 5;

    //programma che predecrementa
    while (i > 0)
    {
        printf("numero di cicli pre: %d\n", --i);
    }
    //programma che postdecrementa
    while (y > 0)
    {
        printf("\nnumero di cicli post: %d", y--);
    }  
}