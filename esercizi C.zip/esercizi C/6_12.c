/*scrivete dei cicli che effettuino ognina delle seguenti operazioni su array unidimensionali:
a) inizializzare a 0 i 10 elementi dell'array intero counts
b) aggiungere 1 a ognuno dei 15 elementi dell'array intero bonus
c) leggere i 12 valori dell'array monthlyTemperatures di tipo float dalla tastiera
d)stampare i cinque valori dell'array intero bestScores nel formato a colonne*/
#include <stdio.h>

int main(){
    int counts[10] = {0};

    int bonus[15] = {0};

    for(size_t i = 0; i < 15; i++){
        bonus[i] += 1;
    }

    float monthlyTemperatures[12] = {0};
    for(size_t i = 0; i < 12; i++){
        printf("inserisci temperatura %zu: ", i + 1);
        scanf("%f", &monthlyTemperatures[i]);
    }

    int bestScores[5] = {1, 2, 3, 4, 5};
    puts("\nbest scores:");
     for(size_t i = 0; i < 5; i++){
        printf("%4d", bestScores[i]);
    }
}