#include <stdio.h>

int main(){
    int i=1;
    int righe=1;

    while (i <= 8 && righe <= 8 )
    {
        printf("* ");
        if (i == 8)
        {
            printf("\n");
            righe++;
            if(righe%2 == 0){
            printf(" ");
            }
            i =0;   
        }
        
        i++;
    }
    
}