/*il bubble sort presentato nella figura 6.12 è inefficiente per array grandi. apportate le modifiche seguenti per migliorare 
le sue prestazioni:
a) dopo la prima passata, è garantito che il numero più grande si trova nell'elemento dell'array col numero più alto; dopo
la seconda passata, i due numeri più grandi sono al "loro posto", e così via. invece di fare nove confronti a ogni passata, 
modificate il bubble sort per fare otto confronti alla seconda passata, sette alla terza e così via.
b)i dati nell'array possono essere nell'ordine giusto o quasi giusto , allora perchè fare nove passate se ne basterebbero di meno
. modificate l'ordinamento per controllare alla fine di ogni passata se sono stati fatti degli scambi. se non ne sono stati fatti, 
allora i dati devono già essere nell'ordine giusto, così l'ordinamento dovrebbe terminare. se sono stati fatti degli scambi allora
è necessaria almeno un'altra passata*/
#include <stdio.h>
#define SIZE 10

int main(){
    int a[SIZE] = {2, 6, 4, 8, 10, 12, 89, 68, 45, 37};

    puts("data items in original order");

    for(size_t i = 0; i < SIZE; i++){
        printf("%4d", a[i]);
    }

    for(int pass = 0; pass < SIZE; pass++){
        int scambi = 0;

        for(size_t i = 0; i < SIZE -1 - pass; i++){
            if(a[i] > a[i + 1]){
                int hold = a[i];
                a[i] = a[i + 1];
                a[i + 1] = hold;
                scambi++;
            }
        }
        
        if(scambi == 0){
            break;
        }
    }

    puts("\ndata items in ascending order");

    for(size_t i = 0; i < SIZE; i++){
        printf("%4d", a[i]);
    }
}