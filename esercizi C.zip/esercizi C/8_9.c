/*(confronto di stringhe) scrivete un programma che usi la funzione strcmp per confrontare due stringhe inserite dall'utente.
il programma deve stabilire se la prima stringa è minore, maggiore o uguale alla secoda.*/
#include <stdio.h>
#include <string.h>

#define SIZE 100

int main(){
    char a[SIZE];
    char b[SIZE];

    printf("inserisci una stringa: ");
    fgets(a, SIZE, stdin);

    printf("inserisci la seconda stringa: ");
    fgets(b, SIZE, stdin);

    printf("%s %d %s", "le prima stringa e'(0 uguale, 1 maggiore, -1 minore): ", strcmp(a, b), "rispetto alla seconda");
}