/*(conversione di stringhe in numeri in virgola mobile per effettuare calcoli) scrivete un programma che legga quattro stringhe 
che rappresentano valori in virgola mobile, converta le stringhein valori double , sommi i valori e stampi il totale dei quarttro valori*/
#include <stdio.h>
#include <stdlib.h>

int main(){
    char a[] = "23.4 34.4 34.3  453.9";
    char *ptr = a;
    double totale = 0;

    while(*ptr){
        double valore = strtod(ptr, &ptr);
        printf("il numero e': %.2f\n", valore);
        totale += valore;
    }

    printf("la somma e': %.2f", totale);
}