/*scrivete un programma che valuti il valore della costante matematica e*/
#include <stdio.h>

int main(){
    double e= 1;
    double i= 1;
    double fattoriale= 1;

    while (i < 15)
    {
        e += 1/fattoriale;
        i++;
        fattoriale *= i;
        printf("%.20f\n", e);
    }
    printf("%.15f", e);
    
}