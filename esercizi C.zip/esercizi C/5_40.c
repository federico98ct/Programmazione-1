/*si può chiamare la funzione main ricorsivamente? scrivete un programma contenente una funzione main. includendo la variabile 
locale static count inizializzata a 1. postincrementate e stampate il valore di count ogni volta che main è chiamata. fate eseguire
il programma. che cosa accade?*/
#include <stdio.h>

int main(){
    static int count = 1;

    if (count > 10) // Fermiamo la ricorsione dopo 10 chiamate
        return 0;

    printf("valore di count prima della chiamata: %d\n", count);
    count++;
    return main();
}