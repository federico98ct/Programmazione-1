/*(effettuare ricorsivamente una ricerca in una lista) scrivete una funzione searchList che cerchi ricorsivamente un valore 
specificato in una lista collegata. la funzione deve restituire un puntatore al valore se questo viene trovato , altrimenti deve 
restituire NULL. usate la vostra funzione in un programma di test che crei una lista di interi. il programma deve poi richiedere 
all'utente un valore da cercare nella lista*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct lista{
    int numero;
    struct lista* nextPtr;
};

typedef struct lista Lista;
typedef Lista* ListaPtr;

void push(ListaPtr* topPtr, int n);
void pop(ListaPtr* topPtr);
void stampaLista (ListaPtr topPtr);
int* ricerca(ListaPtr topPtr, int n);


int main(){
    srand(time(NULL));
    ListaPtr cimaPtr = NULL;

    for (size_t i = 0; i < 30; i++){
        int numero = 1 + (rand() % 100);
        push(&cimaPtr, numero);
    }

    stampaLista(cimaPtr);

    int valore;
    printf("inserire numero da ricercare: ");
    scanf("%d", &valore);

    int* risultato = ricerca(cimaPtr, valore);
    if(risultato == NULL){
        printf("il numero %d non e' presente nella lista\n", valore);
    }
    else{
        printf("il numero %d e' presente nella lista\n", *risultato);
    }

    pop(&cimaPtr);
}

void push(ListaPtr* topPtr, int n){
    ListaPtr newPtr = malloc(sizeof(Lista));
    
    if(newPtr == NULL){
        printf("memoria esaurita\n");
        return;
    }

    newPtr->numero = n;
    newPtr->nextPtr = *topPtr;
    *topPtr = newPtr;
}

void stampaLista(ListaPtr topPtr){
    if(topPtr == NULL){
        printf("la lista e' vuota;");
        return;
    }
    while(topPtr != NULL){
        printf("--> %d", topPtr->numero);
        topPtr =topPtr->nextPtr;
    }
    printf("--> NULL\n");
}

void pop(ListaPtr* topPtr){
    if(topPtr == NULL){
        printf("la lista e' vuota\n");
        return;
    }
    while(topPtr != NULL){
        ListaPtr temp = *topPtr;
        *topPtr = (*topPtr)->nextPtr;
        free(temp);
    }
    *topPtr = NULL;
}

int* ricerca(ListaPtr topPtr, int n){
    if (topPtr == NULL) {
        return NULL;
    }
    if (topPtr->numero == n) {
        return &(topPtr->numero);
    }
    return ricerca(topPtr->nextPtr, n);
}