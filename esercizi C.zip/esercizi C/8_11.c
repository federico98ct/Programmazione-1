/*(frasi casuali) utilizate la generazione di numeri casuali per creare frasi in inglese. il vostro programma deve usare quattro 
array di puntatori a char chiamati article, noun, verb e preposition. create una frase selezionando una parola a caso da ogni array 
nell'ordine seguente: article, noun, verb, preposition, article e noun.
concatenate con le parole precedenti ogni parola che viene scelta, usando un array sufficientemente grande da contenere l'intera frase
separate con spazi le parole. la frase finale deve cominciare con una lettera maiuscola e finire con un punto. generate 20 frasi
di questo tipo. modificate il vostro programma per produrre un breve racconto contenente diverse di queste frasi*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#define SIZE 100
#define DIMENSIONE 5
#define FRASI 20

int generaNumero(void); 
char* selettore(char *array[]);
void creaFrase(char frase[], char *scelta[]);

int main(){

    srand(time(NULL));
    char frase[SIZE] = {}; //array che contiene la frase creata

    char *article[DIMENSIONE] = {"the", "a", "one", "some", "many"};
    char *noun[DIMENSIONE] = {"boy", "girl", "dog", "town", "car"};
    char *verb[DIMENSIONE] = {"drove", "jumped", "run", "walked", "skipped"}; 
    char *preposition[DIMENSIONE] = {"to", "from", "over", "under", "on"};

    for(size_t frasi = 0; frasi < FRASI; frasi++){ //article, noun, verb, preposition, article e noun

        frase[0] = '\0';

        for (size_t parole = 1; parole <= 6; parole++) {
            if (parole == 1 || parole == 5) creaFrase(frase, article);
            else if (parole == 2 || parole == 6) creaFrase(frase, noun);
            else if (parole == 3) creaFrase(frase, verb);
            else if (parole == 4) creaFrase(frase, preposition);
        }

        frase[0] = toupper(frase[0]); //metti in maiuscolo la prima lettera della frase
        frase[strlen(frase) - 1] = '\0'; //rimuove lo spazio prima di inserire il punto
        strcat(frase, "."); //aggiungi punto alla fine della frase

        printf("%s\n", frase);
    }

}

int generaNumero(void){
    return rand() % (DIMENSIONE);
}

char* selettore(char *array[]){

    int numero = generaNumero();
    return array[numero];
}

void creaFrase(char frase[], char *scelta[]){

    strcat(frase, selettore(scelta));
    strcat(frase, " ");
}