/*l'interesse semplice su un prestito è calcolato con la formula interest = principal * rate * days / 365; la precedente formula
presume che rate sia il tasso di interesse annuale, quindi effettua la divisione per 365 (giorni). sviluppate un programma che
utilizzi scanf per leggere i valori principal, rate e days per diversi prestiti, e calcoli e stampi l'interesse semplice per ogni 
prestito, usando la formula precedente*/

#include <stdio.h>

int main()
{
    double prestito =0;
    double tasso_interesse =0;
    int termine_giorni =0;

    while (prestito >=0)
    {
        printf("\ninserire ammontare del prestito (-1 per uscire): ");
        scanf("%lf", &prestito);

        if(prestito <= -1)
            break;
        
        printf("inserire tasso di interesse: ");
        scanf("%lf", &tasso_interesse);
        printf("inserire il termine del prestito in giorni: ");
        scanf("%d", &termine_giorni);
        
        double interesse = prestito * tasso_interesse * (double)termine_giorni / 365;
        printf("l'interesse semplice ammonta a: $%.2f\n", interesse);
    }
    
}