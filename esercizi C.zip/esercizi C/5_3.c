#include <stdio.h>
#include <math.h>

int main(){
    double x = -6.4;
    double y = 2;

    printf("la radice quadrata di %.2f e': %.2f\n", x, sqrt(x));
    printf("la radice cubica di %.2f e': %.2f\n", x, cbrt(x));
    printf("la funzione esponenziale e^%.2f e': %.2f\n", x, exp(x));
    printf("il logaritmo naturale di %.2f (in base e) e': %.2f\n", x, log(x));
    printf("il logaritmo di %.2f (in base 10) e': %.2f\n", x, log10(x));
    printf("il valore assoluto di %.2f come numero in virgola mobile e': %.2f\n", x, fabs(x));
    printf("arrotonda %.2f all'intero piu' piccolo non minore di %.2f e': %.2f\n", x, x, ceil(x));
    printf("arrotonda %.2f all'intero piu' grande non maggiore di %.2f e': %.2f\n", x, x, floor(x));
    printf("%.2f elevato ad %.2f e': %.2f\n", x, y, pow(x,y));
    printf("resto di %.2f/%.2f come numero in virgola mobile e': %.2f\n", x, y, fmod(x,y));
    printf("il seno di %.2f in radianti e': %.2f\n", x, sin(x));
    printf("il coseno di %.2f in radianti e': %.2f\n", x, cos(x));
    printf("la tangente di %.2f in radianti e': %.2f\n", x, tan(x));
}