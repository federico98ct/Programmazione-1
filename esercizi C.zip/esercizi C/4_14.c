/*scrivete un programma che calcoli i fattoriali degli interi da 1 a 5 e stampate i risultati in forma di tabella*/
#include <stdio.h>

int main(){
    int fattoriale = 1;

    printf("%-10s%-10s\n", "numero", "fattoriale");

    for (int i = 1; i <= 5; i++)
    {
        fattoriale *= i;
        printf("%-10d%-10d\n", i, fattoriale); 
    }  
}