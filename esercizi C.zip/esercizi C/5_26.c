/*un numero intero è un numero perfetto se i suoi fattori, compreso 1(ma non il numero stesso), hanno come somma il numero stesso.
per esempio, 6 è un numero perfetto perchè 6 = 1 + 2 + 3.
scrivete una funzione isPerfect che determini se il parametro number è un numero perfetto. usate questa funzione in un programma
che determini e stampi tutti i numeri perfetti tra 1 e 1000. stampate i fattori di ogni numero perfetto per confermare che il numero
è effettivamente perfetto*/
#include <stdio.h>

int isPerfect(int numero);
void stampaFattori(int numero);

int main(){

    for(int numero = 1; numero <= 10000; numero++){
        if(isPerfect(numero) == 1){
            printf("%d e' un numero peretto. i sui divisori sono:", numero);
            stampaFattori(numero);
            puts("");
        }
    }
}

int isPerfect(int numero){
    int somma = 0;

    for(int i = 1; i < numero; i++){
        if(numero % i == 0){
            somma += i;
        }
    }
    
    return somma == numero;   
}

void stampaFattori(int numero){
    for(int i = 1; i < numero; i++){
        if(numero % i == 0){
            printf(" %d", i);
        }
    }
}
