/*scrivete un programma che stampi separatamente i seguenti schemi , uno sotto l'altro. usate dei cicli for per generare gli schemi
tutti gli asterischi (*) devono essere stampati da una singola istruzione printf della forma printf("%s", "*"); */
#include <stdio.h>

int main(){
    for (int i = 1; i <= 10; i++)
    {
        for (int temp = i; temp > 0 && i <= 10; temp--)
        {
            printf("*");
        }
        printf("\n");
    }

    printf("\n");

    for (int i = 10; i > 0; i--)
    {
        for (int temp = i; temp > 0; temp--)
        {
            printf("*");
        }
        printf("\n");
    }

    printf("\n");

    int ciclo = 0;
    for (int i = 10; i > 0; i--)
    {
        for (int temp = i; temp > 0; temp--)
        {
            printf("*");
        }

        printf("\n");
        ciclo += 1;
        
        for ( int spazio = 1; spazio <= ciclo; spazio++)
        {
            printf(" ");
        }
    }

    printf("\n");

    
    for (int i = 1; i < 10; i++)
    {
        for ( int spazio = 10-i; spazio > 0; spazio--)
        {
            printf(" ");
        }

        for (int temp = i; temp > 0; temp--)
        {
            printf("*");
        }

        printf("\n");
        
    }


    
}