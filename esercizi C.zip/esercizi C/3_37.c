/*scrivete un programma che stampi 100 asterischi, uno alla volta. dopo ogni decimo asterisco, il programma deve stampare un 
carattere newline*/
#include <stdio.h>

int main(){
    int contatore =1;

    while(contatore <=100){
        printf("*");

        if(contatore%10 == 0){
            printf("\n");
        }
        contatore++;
    }
}