/*scrivete un programma che legga un numero intero (di 5 cifre o meno) e determini e stampi quante cifre uguali a 7
ci sono nel numero*/
#include <stdio.h>

int main(){
    int numero = 0;
    int conta_7 = 0;
    int modulo = 0;

    printf("inserisci un numero (massimo 5 cifre): ");
    scanf("%d", &numero);

    if(numero > 99999){
        printf("numero non valido, assicurarsi di aver iserito un numero di massimo 5 cifre");
    }
    while (numero > 0)
    {
        modulo = numero%10;
        if(modulo == 7){
            conta_7 += 1;
        }
        numero /=10;
    }  
    if(conta_7 > 0){
        printf("i 7 all'interno del numero sono: %d", conta_7);

    }
}