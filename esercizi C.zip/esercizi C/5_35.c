/*la serie di fibonacci (0,1,1,2,3,5,8,13,21,...) inizia con i termini 0 e 1 e ha la proprietà che che ogni termine che segue è la somma 
dei due termini precedenti, scrivete una funzione fibonacci(n) non ricorsiva che calcoli l'nmo numero di fibonacci. usate int per
il parametro della funzione e unsigned long long int per il suo tipo di ritorno. poi, determinate il numero di fibonacci più grande 
che può essere stampato sul vostro sistema*/
#include <stdio.h>

unsigned long long int fibonacci(int numero);

int main(){
    int numero = 0;
    printf("inserisci l'nmo numero da calcolare: ");
    scanf("%d", &numero);
    printf("il numero e': %llu", fibonacci(numero));
}

unsigned long long int fibonacci(int numero){

    unsigned long long int precedente = 0;
    unsigned long long int successivo = 1;
    unsigned long long int somma = 0;

    if(numero == 0) return 0;
    if(numero == 1) return 1;

    for(int i = 2; i <= numero; i++){
        somma = precedente + successivo; 
        precedente = successivo;
        successivo = somma;  
    }

    return successivo;
}