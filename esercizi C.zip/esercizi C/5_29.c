/*scrivete la funzione gcd che restituisce il massimo comun divisore di due interi*/
#include <stdio.h>
#include <math.h>

int MCD(int numero1, int nummero2);

int main(){
    int numero1 = 0;
    int numero2 = 0;

    printf("inserisci due numeri interi: ");
    if(scanf("%d%d", &numero1, &numero2) == 2){
        printf("il loro MCD e': %d", MCD(numero1, numero2));
    }
    else
        printf("\ninserisci dei dati validi");
}

int MCD(int numero1, int numero2){
    int MCD = 0;
    int divisore1 = 0;
    int divisore2 = 0;
    int minore = (numero1 < numero2) ? numero1 : numero2;
    
    for(int i = 1; i <= minore; i++){
        if(numero1 % i == 0){
            divisore1 = i;
        }
        if(numero2 % i == 0){
            divisore2 = i;
        }
        if(divisore1 == divisore2){
            MCD = divisore1;
        }
    }

    return MCD;
}