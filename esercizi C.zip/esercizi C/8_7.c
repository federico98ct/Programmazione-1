/*(conversione di stringhe in numeri in virgola mobile per effettuare calcoli) scrivete un programma che legga quattro stringhe 
che rappresentano valori interi, converta le stringhe in interi, sommi i valori e stampi il totale dei quattro valori*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(){

    int somma = 0;
    char array[] = "456 346 35 231";
    char *ptr = array;

    while(*ptr){

        int valore = strtol(ptr, &ptr, 10);
        printf("Il numero e': %d\n", valore);
        somma += valore;
    }
    
    printf("la loro somma e': %d", somma);
    
}