/*(latino maccheronico) scrivete un programma che trasformi frasi della lingua inglese in latino maccheronico. il latino maccheronico
è una forma di linguaggio codificato usato spesso per divertimento. usiamo l'algoritmo seguente:
per formare una frase in latino maccheronico da una frase della lingua inglese, spezzate con la funzione strtok la frase nelle sue 
parole costituenti. per tradurre ogni parola inglese in una parola in latino maccheronico, spostate la prima lettera della parola
inglese alla fine della parola e aggiungete le lettere ay. in questo modo la parola "jump" diventa umpjay e così via. gli spazi tra le 
parole rimangono tali. presupponete quanto segue: la frase inglese è formata da parole separate da spazi, non vi sono segni di
interpunzionee tutte le parole hanno due o più lettere. la funzione printLatinWord deve stampare ogni parola.[suggerimento: ogni
volta che in una chiamata strtok si trova un token, passate il puntatore al token alla funzione printLatinWord e stampate la parola in 
latino maccheronico.]*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define SIZE 100

void printLatinWord(char frase[]);

int main(){
    char frase[SIZE];
    printf("**benvenuto nel programma di traduzione da inglese a inglese maccheronico**\n");
    printf("prego inserire una frase: ");
    fgets(frase, SIZE, stdin);
    if(strlen(frase) > 0) frase[strlen(frase) - 1] = '\0';
    
    char *fptr = frase;
    fptr = strtok(fptr, " ,.;:\"/");
    
    while(fptr != NULL){
        printLatinWord(fptr);
        fptr = strtok(NULL, " ,.;:\"/");
    }
    
}

void printLatinWord(char frase[]){
    char c = frase[0]; //memorizza la prima lettera della parola
    int lunghezza = strlen(frase); //determina la lunghezza della parola
    char suffisso[] = "ai"; //suffisso da postporre alla parola

    for (size_t i = 1; i < lunghezza; i++){
        printf("%c", frase[i]);
    }

    printf("%c%s ", c, suffisso);
}

