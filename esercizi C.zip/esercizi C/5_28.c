/*scrivete una funzione che riceva un valore intero e restituisca il numero con le sue cifre invertite.*/
#include <stdio.h>
#include <stdlib.h>

int invertiNumero(int numero);

int main(){
    int numero = 0;

    printf("inserisci un numero intero: ");
    scanf("%d", &numero);
    printf("il numero invertito e': %d", invertiNumero(numero));
}

int invertiNumero(int numero){
    if (numero == 0) return 0;  

    int temp = abs(numero);
    int numeroinvertito = 0;

    while(temp > 0){
       numeroinvertito = numeroinvertito * 10 + (temp % 10);
       temp/=10;
    }

    return (numero < 0) ? - numeroinvertito : numeroinvertito;
}