/*scrivete una funzione integerPower(base, exponent) che restituisca il valore di base^exponent
per esempio, integerPower(3, 4) = 3*3*3*3. supponete che exponent sia un intero positivo diverso da zero e che base sia un intero
la funzione integerPower deve usare un'istruzione for per controllare il calcolo. non usate alcuna funzione della libreria math*/
#include <stdio.h>

int integerPower(int base, int esponente);

int main(){
    int base= 0;
    int esponente = 0;

    printf("inserisci la base e l'esponente: ");
    if(scanf("%d%d", &base, &esponente) == 2 && esponente > 0){
        printf("il risultato e': %d", integerPower(base, esponente));
    }
}

int integerPower(int base, int esponente){
    int risultato = 1;
    for(int i = 0;i < esponente; i++){
        risultato *= base;
    }
    return risultato;
}