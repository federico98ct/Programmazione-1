/*una piccola compagnia aerea ha appena acquistato un computer per il suo nuovo sistema automatico di prenotazione. il presidente
vi ha chiesto di programmare il nuovo sistema. scriverete un programma per assegnare i posti su ogni volo dell'unico aereo della 
compagnia (capacità: 10 posti). il vostro programma deve stampare il seguente menù di alternative:
please type 1 for "first class"
please type 2 for "economy"
se la persona scrive 1 allora il vostro programma deve assegnare un posto in prima classe (posti da 1 a 5). se la persona scrive 2,
allora il vostro programma deve assegnare un posto in classe economica (posti da 6 a 10). il vostro programma deve quindi stampare 
una carta di imbarco indicante il numero del posto della persona e se questo si trova in prima classe o in economica.
usate un arrai unidimensionale per rappresentare la mappa dei posti dell'aereo. inizializzate tutti gli elementi dell'array a 0 
per indicare che tutti i posti sono vuoti. quado ogni posto viene assegnato, impostate a 1 l'elemento corrispondente dell'array 
per indicare che il posto non è più disponibile.
il vostro programma, naturalmente, non deve mai assegnare un posto che è già stato assegnato. quando la prima classe è piena il 
vostro programma deve domandare alla persona se è disposta ad accettare un posto in classe economica e viceversa. se lo è assegnate
il posto appropriato; se non lo è stampate il messaggio, "next flight leaves in 3 hours".*/
#include <stdio.h>

#define SIZE 10

int assegnaPosti(int a[],int min, int max);

int main(){
    int sceltaClasse = 0;
    int procedere;
    int posti[SIZE] = {0};

    for(size_t i = 1; i <= SIZE; i++){
        printf("please type 1 for\"first class\"\nplease type 2 for\"economy\"\nselect class: ");
        if(scanf("%d", &sceltaClasse) == 1 && sceltaClasse >= 1 && sceltaClasse <= 2){

            int postoAssegnato = 0;
            
            if(sceltaClasse == 1){
                postoAssegnato = assegnaPosti(posti,0, 5);

                if(postoAssegnato == 0){
                    printf("posti di prima classe esauriti.\nvuole procedere con l'acuisto di un posto in economy?(1 o 0): ");
                    scanf("%d", &procedere);

                    if(procedere == 1){
                        postoAssegnato = assegnaPosti(posti, 5, 10);
                    }
                    else{
                        printf("next flight leaves in 3 hours\n");
                        i--;
                    }
                }
            }
            if(sceltaClasse == 2){
                postoAssegnato = assegnaPosti(posti,5, 10);

                if(postoAssegnato == 0){
                    printf("posti economy esauriti.\nvuole procedere con l'acuisto di un posto in prima classe?(1 o 0): ");
                    scanf("%d", &procedere);

                    if(procedere == 1){
                        postoAssegnato = assegnaPosti(posti, 0, 5);
                    }
                    else{
                        printf("next flight leaves in 3 hours\n");
                        i--;
                    }
                }
            }
        }
        else{
            printf("inserisci un valore valido!\n");
            i--;
        }
        puts("");
    }
}

int assegnaPosti(int a[],int min, int max){
    int count = 0;
    for(size_t x = min; x < max; x++){
        if(a[x] == 0){
            a[x] = 1;
            count = x + 1;
            break;
        }
    }
    if(count < 5 && count != 0){
        printf("le e' stato assegnato il posto numero %d della prima classe.\n", count);
    }
    else if(count >= 5 && count != 0){
        printf("le e' stato assegnato il posto numero %d della economy.\n", count);
    }
    return count;
}