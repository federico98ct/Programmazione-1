/*scrivete un programma che utilizzi l'iterazione per riprodurre la seguente tabella di valori A   A+2   A+4   A+6*/

#include <stdio.h>

int main()
{
    int A =3;
    int N =1;
    printf("A\tA+2\tA+4\tA+6\n\n");

    while (N <=5)
    {
        printf("%d\t%d\t%d\t%d\n", A*N, A*N+2, A*N+4, A*N+6);
        N++;
    }
    
}