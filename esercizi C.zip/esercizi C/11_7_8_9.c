#include <stdio.h>

typedef struct {
    size_t numeroConto;
    char nome[30];
    double saldo;
} Cliente;

int main() {

    // apri file principale 
    FILE *ofPtr = fopen("datiCliente.txt", "w+");
    if (ofPtr == NULL) {
        printf("Impossibile aprire il file\n");
        return 1;
    }

    Cliente accountCliente[] = { //dati file principale
        {100, "Alan_Jones", 348.17},
        {300, "Mary_Smith", 27.19},
        {500, "Sam_Sharp", 0.00},
        {700, "Suzy_Green", -14.22}
    };

    size_t numClienti = sizeof(accountCliente) / sizeof(accountCliente[0]);

    for (size_t i = 0; i < numClienti; i++) { //scrittura su file principale
        fprintf(ofPtr, "%zu %s %.2f\n",
                accountCliente[i].numeroConto,
                accountCliente[i].nome,
                accountCliente[i].saldo);
    }


    // apri file transizioni
    FILE *tfPtr = fopen("transizioniCliente.txt", "w+");
    if (tfPtr == NULL) {
        printf("Impossibile aprire il file\n");
        return 1;
    }

    Cliente transazioni[] = { //dati file transazioni
        {100, "", 27.14},
        {300, "", 62.11},
        {400, "", 100.56},
        {900, "", 82.17},
        {300, "", 83.89},
        {700, "", 80.78},
        {700, "", 1.53}
    };

    size_t nTransazioni = sizeof(transazioni)/sizeof(transazioni[0]);

    for (size_t i = 0; i < nTransazioni; i++) { //scrittura file transazioni
        fprintf(tfPtr, "%zu %.2f\n",
            transazioni[i].numeroConto,
            transazioni[i].saldo);
    }

    //riporta i puntatori in cima ai file
    rewind(ofPtr);
    rewind(tfPtr);

    //apri file nuovo
    FILE *nfPtr = fopen("nuovoStorico.txt", "w+");
    if(nfPtr == NULL){
        printf("impossibile aprire il file\n");
        return 1;
    }

    //array per i dati letti
    Cliente lettura_cliente[numClienti];
    Cliente lettura_transazioni[nTransazioni];

    //lettura file dati cliente
    for (size_t i = 0; i < numClienti; i++){
        fscanf(ofPtr, "%zu %s %lf", &lettura_cliente[i].numeroConto, lettura_cliente[i].nome, &lettura_cliente[i].saldo);
    }  

    //lettura file transizioni clienti
    for (size_t i = 0; i < nTransazioni; i++){
        fscanf(tfPtr, "%zu %lf", &lettura_transazioni[i].numeroConto, &lettura_transazioni[i].saldo);
    }
    
    int trovato; 
    int transazioneUsata[nTransazioni];
    for (size_t k = 0; k < nTransazioni; k++) {
    transazioneUsata[k] = 0;
    }

    for (size_t i = 0; i < numClienti; i++){
        trovato = 0;
        double sommaTransazioni = 0.0;
        for (size_t j = 0; j < nTransazioni; j++){
            if(lettura_cliente[i].numeroConto == lettura_transazioni[j].numeroConto){

                sommaTransazioni += lettura_transazioni[j].saldo; //calcolo somma delle transazioni per cliente

                //aggiorna array dei dati trovati
                transazioneUsata[j] = 1;
                trovato = 1;
            }
        }

        if(trovato){
            double nuovoSaldo = lettura_cliente[i].saldo -  sommaTransazioni; //calcolo nuovo saldo
            //copia del nuovo saldo sul nuovo file
            fprintf(nfPtr, "%zu %s %.2f\n", lettura_cliente[i].numeroConto, lettura_cliente[i].nome, nuovoSaldo);
        }

        else{
            fprintf(nfPtr, "%zu %s %.2f %s\n", lettura_cliente[i].numeroConto, lettura_cliente[i].nome, lettura_cliente[i].saldo, "non ha effettuato transizioni");
        }
    }

    // Gestione clienti non registrati
    for (size_t j = 0; j < nTransazioni; j++) {
        if (!transazioneUsata[j]) {
            fprintf(nfPtr, "%zu %s\n",
                    lettura_transazioni[j].numeroConto,
                    "cliente non presente nel database");
        }
    }

    //chiudi tutti i file aperti
    fclose(ofPtr);
    fclose(tfPtr);
    fclose(nfPtr);

}