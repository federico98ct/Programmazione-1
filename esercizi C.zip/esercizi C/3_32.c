/*scrivete un programma che legga il lato di un quadrato e poi stampi quel quadrato con asterischi. il programma deve operare
con quadrati delle dimensioni dei lati tra 1 e 20. */

#include <stdio.h>

int main() {
    int lato;
    int i = 0;
    int j =0;

    // Richiede all'utente di inserire la dimensione del lato
    printf("Inserisci la dimensione del lato del quadrato (tra 1 e 20): ");
    scanf("%d", &lato);

    // Controlla che il lato sia valido
    if (lato >= 1 && lato <= 20) {
        // Stampa il quadrato usando cicli while
        while (i < lato) {
            j = 0;
            while (j < lato) {
                printf("*");
                j++;
            }
            printf("\n");
            i++;
        }
    } else {
        printf("Errore: il lato deve essere compreso tra 1 e 20.\n");
    }

    return 0;
}