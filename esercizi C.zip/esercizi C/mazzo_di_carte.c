#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SEMI 4
#define FACCE 13
#define CARTE 52

void mischia(int mazzo[][FACCE]);
void distribuisci(int mazzo[][FACCE], const char *faccia[], const char *seme[]);

int main(){
    int mazzo[SEMI][FACCE] = {0};

    srand(time(NULL));
    mischia(mazzo);

    const char *seme [SEMI] = {"Cuori", "Quadri", "Fiori", "Picche"};
    const char *faccia [FACCE] = {"Asso", "Due", "Tre", "Quattro", "Cinque", 
        "Sei", "Sette", "Otto", "Nove", "Dieci", "Jack", "Regina", "Re"};

    distribuisci(mazzo, faccia, seme);
}

void mischia(int mazzo[][FACCE]){
    for(size_t carta = 1; carta <= CARTE; carta ++){

        size_t riga = 0;
        size_t colonna = 0;

        do{
            riga = rand() % SEMI;
            colonna = rand() % FACCE;
        } while (mazzo[riga][colonna] != 0);

        mazzo[riga][colonna] = carta;  
    }
}

void distribuisci(int mazzo[][FACCE], const char *faccia[], const char *seme[]){

    for(size_t carta = 1; carta <= CARTE; carta++){
        for(size_t riga = 0; riga < SEMI; riga++){
            for(size_t colonna = 0; colonna < FACCE; colonna++){
                if(mazzo[riga][colonna] == carta){
                    printf("%8s di %-8s  %s", faccia[colonna], seme[riga], carta % 4 == 0 ?  "\n" : "\t");
                }
            }
        }
    }
}