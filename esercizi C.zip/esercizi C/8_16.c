/*scrivete un programma che legga dalla tastiera  una riga di testo e una stringa da ricercare. usando la funzione strstr, cercate
nella riga di testo la prima occorrenza della stringa da ricercare. assegnate l'indirizzo alla variabile searchPtr di tipo char*
se la stringa viene trovata, stampate il resto della riga di testo cominciando con tale stringa. poi usate di nuovo strstrper 
localizzare la successiva occorrenza della stringa nella riga di testo. se questa viene trovata, stampate il resto della riga di testo
cominciando con la seconda occorrenza[suggerimento: la seconda chiamata a strstr deve contenere searchPtr + 1 come suo primo argomento]*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 100

void chiediStringa(char array[]);

int main(){
    char stringa[SIZE] = "";
    char stringaRicerca[SIZE] = "";
    
    printf("inserisci una riga di testo: "); //inserimento prima stringa
    chiediStringa(stringa);

    printf("inserisci la stringa da ricercare: "); //inserimento stringa da cercare
    chiediStringa(stringaRicerca);

    char *searchPtr = strstr(stringa, stringaRicerca);
    if(searchPtr == NULL){
        printf("stringa non trovata!");
        return 0;
    }

    while(searchPtr != NULL){
        printf("%s\n", searchPtr);
        searchPtr = strstr(searchPtr + 1, stringaRicerca);
    }
    
}

void chiediStringa(char array[]){

    fgets(array, SIZE, stdin);
    array[strcspn(array, "\n")] = '\0'; //rimozione \n
}

