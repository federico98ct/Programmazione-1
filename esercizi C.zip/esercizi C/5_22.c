/*scrivete segmenti di programma che effettuino le seguenti operazioni:
a)calcolo della parte int del quoziente quando int a è diviso per int b.
b)calcolo del resto int quando int a è diviso per int b.
c)usate le parti di programma sviluppate in a) e b) per scrivere una funzione che riceva in ingresso un intero tra 1 e 32767 e 
lo stampi come una sequenza di cifre, con due spazi tra ognuna di esse.*/
#include <stdio.h>

void stampaCifre(int numero);
int main(){
    int a = 123;
    int b = 45;

    int divisione = a/b;
    int resto = a%b;
    printf("%d\n", divisione);
    printf("%d\n", resto);

    int numero = 0;

    while(1){
        printf("inserisci un numero intero (compreso tra 1 e 32767): ");
        if(scanf("%d", &numero) == 1 && numero >= 1 && numero <= 32767){
            stampaCifre(numero);
            break;
        }
        else{
            printf("inserisci un numero valido\n");
            while (getchar() != '\n');
        }
    }
}

void stampaCifre(int numero){
   int temp = numero;
   int decimale = 1;

   while(temp >= 10){ //conta le posizioni decimali
    temp/=10;
    decimale*=10;
   }

   while(decimale > 0){ //stampa le singole cifre del numero
    printf("%d  ", numero/decimale);
    numero %= decimale;
    decimale/=10;
   }

}