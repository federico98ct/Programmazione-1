#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main(){
    char c = 'x';
    int x, y, z;
    double d, e, f;
    char *ptr;
    char s1[100];
    char s2[100] = {"1.27 10.3 9.432 X erenc"};

    //a) onvertire il carattere memorizzato nella variabile c in una lettera maiuscola. assegnate il risultato alla variabile c.
    
    printf("toupper(%c)= ", c);
    c = toupper(c);
    printf("%c\n", c);
    
    //b) determinare se il valore della variabile c è una cifra. usate l'operatore condizionale.

    printf("%c %s %s\n", c, isdigit(c) ? "e'" : "non e'", "una cifra(0-9)");

    //c) determinare se il valore della variabile c è un carattere di controllo. usate l'operatore condizionale

    printf("%c %s %s\n", c, iscntrl(c) ? "e'" : "non e'", "una variabile di controllo");

    //d) leggete una riga di testo dalla tastiera e memorizzatela nell'array s1, non usate scanf

    printf("Inserisci una stringa: ");
    fgets(s1, 100, stdin);

    //e) stampate la riga di testo memorizzata nell'array s1. non usate printf.

    puts(s1);

    //f) assegnate a ptr l'indirizzo dell'ultima occorrenza di c in s1
    
    ptr = strrchr(s1, c); //ricorda che hai impostato c a maiuscolo
    printf("%s\n", ptr);

    //g) stampate il valore della variabile c, non usate printf

    putchar(c);

    //h) determinate se il valore di c è una lettera. usate l'operatore condizionale

    printf("\n%c %s %s\n", c, isalpha(c) ? "e'" : "non e'", "una lettera");

    //i) leggete un carattere dalla tastiera e memorizzatelo nella variabile c

    printf("inserisci un carattere: ");
    c = getchar();
    printf("%c\n", c);

    //j) assegnate a ptr la locazione della prima occorrenza di s2 in s1
    ptr = strstr(s1, s2);
    printf("%s\n", ptr);

    //k) determinate se il valore della variabile c è un carattere stampabile. usate l'operatore condizionale 

    printf("\n%c %s %s\n", c, isprint(c) ? "e' un" : "non e' un", "carattere stampabile");

    //l) leggete tre valori double nelle variabili d, e ed f dalla stringa "1.27 10.3 9.432"
    
    d = strtod(s2, &ptr);
    e = strtod(ptr, &ptr);
    f = strtod(ptr, &ptr);
    printf("%f %f %f\n", d, e, f);

    //m) copiate la stringa memorizzata nell'array s2 nell'array s1

    strcpy(s1, s2);
    puts(s1);

    //n) assegnate a ptr la locazione della prima occorrenza di c in s1
    ptr = strchr(s1, c);
    printf("\n%c", *ptr);

    //o) confrontate la stringa in s1 con la stringa in s2. stampate il risultato

    printf("strcmp(s1, s2) = %d\n", strcmp(s1, s2));

    //p) assegnate a ptr la locazione della prima occorrenza di c in s1
    
    
}