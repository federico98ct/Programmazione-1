/*scrivete un programma che utilizzi l'iterazione per stampare i numeri da 1 a 10 l'uno accanto all'altro sulla stessa riga 
con tre spazi tra di loro.*/

#include <stdio.h>

int main()
{
    int i =1;

    while (i <= 10)
    {
        printf("%d   ", i++);
    }   
}