/*usate un array unidimensionale per risolvere il seguente problema. memorizzate 20 numeri, ognuno dei quali compreso 
tra 10 e 100, estremi inclusi. quando un numero viene letto, stampatelo solo se non è un duplicato di un numero già letto.
tenete conto del caso peggiore, in cui tutti i 20 numeri sono differenti. usate l'array più piccolo possibile per risolvere questo problema */
#include <stdio.h>
#define SIZE 20

int main(){
    int numeri[SIZE];
    int dimensione = 0;

    for(size_t i = 0; i < SIZE; i++){
        int temp;
        printf("inserisci un numero(tra 10 e 100): ");
        scanf("%d", &temp);
        
        int copia = 0;
        for(size_t x = 0; x < dimensione; x++){
            if(temp == numeri[x]){
                copia = 1;
                break;
            }
        }
        if(copia != 1){
            printf("il numero e': %d\n", temp);
            numeri[dimensione] = temp;
            dimensione++;
        }

    }
    printf("dimensione = %d", dimensione);
}