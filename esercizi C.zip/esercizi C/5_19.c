/*scrivete una funzione che stampi un quadrato di asterischi pieno il cui lato è specificato nel parametro intero side*/
#include <stdio.h>

void stampaQuadrato(int lato);

int main(){
    int lato = 0;

    printf("inserisci il valore del lato: ");
    if(scanf("%d", &lato) == 1 && lato > 0){
        stampaQuadrato(lato);
    }
    else{
        printf("inserisci un valore valido");
    }
}

void stampaQuadrato (int lato){
    for(int i = 1; i <= lato; i++){
        for(int j = 1; j<= lato; j++){
            printf("*");
        }
        puts("");
    }
}