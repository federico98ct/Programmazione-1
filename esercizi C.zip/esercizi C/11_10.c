#include <stdio.h>
#include <string.h>

typedef struct {
    char lastName[15];
    char firstName[15];
    char age[4];
} Person;

void esportaInTxt(const char *binName, const char *txtName) {
    FILE *binFile = fopen(binName, "rb");
    FILE *txtFile = fopen(txtName, "w");
    if (binFile == NULL || txtFile == NULL) {
        printf("Errore durante l'esportazione in .txt\n");
        return;
    }

    Person p;
    int index = 0;
    while (fread(&p, sizeof(Person), 1, binFile) == 1) {
        fprintf(txtFile, "[%2d] %-15s %-15s %-4s\n", index, p.lastName, p.firstName, p.age);
        index++;
    }

    fclose(binFile);
    fclose(txtFile);
    printf("Esportazione completata su '%s'\n", txtName);
}

int main() {
    FILE *pfPtr = fopen("nameage.dat", "wb+"); // Tronca file
    if (pfPtr == NULL) {
        printf("Impossibile aprire il file!\n");
        return 1;
    }

    // a) Inizializza 100 record "vuoti"
    Person person = {"unsigned", "0", "0"};
    for (size_t i = 0; i < 100; i++) {
        fwrite(&person, sizeof(Person), 1, pfPtr);
    }

    // b) Inserisci 10 record reali
    for (size_t i = 0; i < 3; i++) {
        printf("Inserisci cognome, nome ed eta': ");
        scanf("%14s %14s %3s", person.lastName, person.firstName, person.age);
        fseek(pfPtr, sizeof(Person) * i, SEEK_SET);
        fwrite(&person, sizeof(Person), 1, pfPtr);
    }

    // c) Sovrascrive solo i record "unsigned" → "no info"
        rewind(pfPtr);
    for (size_t i = 0; i < 100; i++) {
        Person temp;

        fseek(pfPtr, sizeof(Person) * i, SEEK_SET);
        fread(&temp, sizeof(Person), 1, pfPtr);

        if (strcmp(temp.lastName, "unsigned") == 0) {
            Person noinfo = {"no info", "", ""};
            fseek(pfPtr, sizeof(Person) * i, SEEK_SET);
            fwrite(&noinfo, sizeof(Person), 1, pfPtr);
        }
}

    // d) Reinizializza un record a scelta
    int index;
    printf("Quale record vuoi reinizializzare (0-99)? ");
    scanf("%d", &index);
    if (index >= 0 && index < 100) {
        Person reset = {"unsigned", "0", "0"};
        fseek(pfPtr, sizeof(Person) * index, SEEK_SET);
        fwrite(&reset, sizeof(Person), 1, pfPtr);
        printf("Record %d reinizializzato.\n", index);
    } else {
        printf("Indice non valido.\n");
    }

    fclose(pfPtr);

    // f) Esporta in testo leggibile
    esportaInTxt("nameage.dat", "nameage.txt");

    return 0;
}