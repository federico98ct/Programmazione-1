/*scrivete un programma che calcoli e stampi la somma degli interi pari da 2 a 30*/
#include <stdio.h>

int main(){
    int somma =0;
    
    for (int i = 2; i <= 30; i+=2)
    {
        somma += i;
    }

    printf("la somma e': %d\n", somma);
    
}