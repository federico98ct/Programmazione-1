/*il linguaggio logo ha reso famoso il concetto dei grafici a tartaruga. immaginate una tartaruga meccanica che cammini intorno 
in una stanza sotto il controllo di un programma in C. la tartaruga tiene una penna che può trovarsi in una di due posizioni, in 
su o in giù. finche la penna sta in giù, la tartaruga traccia delle forme mentre si muove; finchè la penna sta in sù, la tartaruga 
si muove intorno liberamente senza scrivere nulla. in questo problema simulerete l'operazione della tartaruga e creerete anche un 
foglio da disegno computerizzato.
usate un array floor 50x50 inizializzato a 0. leggete i comandi da un array che li contiene. tenete continuamente traccia della 
posizione corrente della tartaruga e della posizione della pena, in su o in giù. supponete che la tartaruga parta sempre alla 
posizione 0, 0 del pavimento con la sua penna in su. l'insieme di comandi della tartaruga che il vostro programma deve elaborare 
è mostrato sotto:
a) 1 penna in su
b) 2 penna in giù
c) 3 gira a destra
d) 4 gira a sinistra 
e) 5, 10 spostati avanti di 10 posizioni (o di un numero diverso da 10)
f) 6 stampa l'array 50x50
g) 9 fine dei dati(sentinella)
supponete che la tartaruga sia da qualche parte vicino al centro del pavimento. il seguene programma disegnae stampa un quadrato di 
12x12:
2
5, 12
3
5, 12
3
5, 12
3
5, 12
1
6
9
quando la tartaruga si muove con la penna in giù, impostate a 1 gli elementi dell'array floor. quando viene dato il comando 6, 
stampate un asterisco ovunque vi sia un 1 nell'array. per ogni 0, stampate uno spazio. scrivete un programma per implementare 
le funzionalità dei grafici a tartaruga esaminate qui. scrivete diversi programmi per grafici a tartaruga per disegnare forme 
interessanti. aggiungete altri comandi per aumentare la potenza del vostro linguaggio per i grafici a tartaruga*/
#include <stdio.h>

#define SIZE 50
#define MAX_COMANDI 100  // Limite massimo di comandi

void movimentiTartaruga(int comandi[], int dimensione);
int validazioneComandi(int a);

int main() {
    int comandi[MAX_COMANDI];  // Array a dimensione fissa
    int dimensione = 0; // Contatore per i comandi inseriti
    
    printf("Benvenuto nei grafici a tartaruga!\nRegole:\n");
    printf("1 - Penna in su\n2 - Penna in giù\n3 - Gira a destra\n4 - Gira a sinistra\n");
    printf("5 - Spostati avanti di N posizioni\n6 - Stampa la griglia\n9 - Fine dei dati\n\n");

    while (1) {
        printf("Inserisci un comando per la tartaruga: ");
        if (scanf("%d", &comandi[dimensione]) == 1) {
            if (!validazioneComandi(comandi[dimensione])) {
                printf("Inserisci un valore valido!\n");
                continue;
            }
            if (comandi[dimensione] == 9) {
                movimentiTartaruga(comandi, dimensione + 1);
                break;
            }
            dimensione++;
        } else {
            printf("Errore di input. Riprova.\n");
        }
    }

    return 0;
}

// Validazione dei comandi
int validazioneComandi(int a) {
    int regole[] = {1, 2, 3, 4, 5, 6, 9};
    for (size_t i = 0; i < 7; i++) {
        if (a == regole[i]) return 1;
    }
    return 0;
}

// Movimenti della tartaruga
void movimentiTartaruga(int comandi[], int dimensione) {
    int floor[SIZE][SIZE] = {0};  // Griglia 50x50
    int penna = 0;
    int x = 0, y = 0;
    int direzione = 0; // 0 = Destra, 1 = Giù, 2 = Sinistra, 3 = Su

    for (size_t i = 0; i < dimensione; i++) {
        switch (comandi[i]) {
            case 1:
                penna = 0; // Penna sollevata
                break;
            case 2:
                penna = 1; // Penna abbassata
                break;
            case 3:
                direzione = (direzione + 1) % 4; // Gira a destra
                break;
            case 4:
                direzione = (direzione - 1 + 4) % 4; // Gira a sinistra
                break;
            case 5:
                printf("Di quanti passi vuoi muovere la tartaruga?: ");
                int passi;
                scanf("%d", &passi);

                for (int j = 0; j < passi; j++) {
                    if (direzione == 0) x++;
                    else if (direzione == 1) y++;
                    else if (direzione == 2) x--;
                    else if (direzione == 3) y--;

                    // Controllo limiti della griglia
                    if (x < 0) x = 0;
                    if (x >= SIZE) x = SIZE - 1;
                    if (y < 0) y = 0;
                    if (y >= SIZE) y = SIZE - 1;

                    if (penna == 1) {
                        floor[y][x] = 1;
                    }
                }
                break;
            case 6:
                // Stampa della griglia
                printf("\nMappa del percorso:\n");
                for (int r = 0; r < SIZE; r++) {
                    for (int c = 0; c < SIZE; c++) {
                        if (floor[r][c] == 1) printf("* ");
                        else printf("  ");
                    }
                    printf("\n");
                }
                break;
        }
    }
}