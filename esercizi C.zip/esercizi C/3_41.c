/*scrivete un programma che legga il raggio di un cerchio (double), e calcoli e stampi il diametro, la circonferena e l'area.*/
#include <stdio.h>

int main(){
    const double pi = 3.14159;
    double raggio =0;

    while (1){    
    printf("\ninserisci il raggio: ");
    scanf("%lf", &raggio);

    double diametro = 2 * raggio;
    double circonferenza = 2 * pi * raggio;
    double area = pi * raggio *raggio;

    printf("il diametro e': %.2f\n", diametro);
    printf("la circonferenza e': %.2f\n", circonferenza);
    printf("l'area e': %.2f\n", area);
    }

}