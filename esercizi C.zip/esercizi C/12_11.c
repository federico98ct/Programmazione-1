/*(test di palindromo) scrivete un programma che usi una pila per determinare se una stringa è un palindromo. il programma deve 
ignorare spazi e punteggiatura*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct pila{
    char c;
    struct pila* nextPtr;
};

typedef struct pila Pila;
typedef Pila* PilaPtr;

#define SIZE 100

void push(PilaPtr *topPtr, char c);
void cancella(PilaPtr* topPtr);

int main(){
    char stringa[SIZE];
    printf("inserisci una stringa: ");
    fgets(stringa, SIZE, stdin); //inserisci stringa
    stringa[strcspn(stringa, "\n")] = '\0'; //rimuovi \n
    int dimensione = strlen(stringa); //dimensione della stringa

    char pulita[SIZE]; //stringa senza spazi e punteggiatura
    int indice = 0; //lunghezza stringa pulita

    for(size_t i = 0; i < dimensione; i++){
        if(isalnum(stringa[i])){
            pulita[indice++] = tolower(stringa[i]);
        }
    }
    pulita[indice] = '\0'; //aggiungi carattere di terminazione

    PilaPtr testaPtr = NULL; //testa della pila
    for(size_t i = 0; i < indice; i++){
        push(&testaPtr, pulita[i]);//inserisci stringa al rovescio
    }

    int controllo = 1;
    for(size_t i = 0; i < indice; i++){
        if(testaPtr->c != pulita[i]){
            controllo = 0;
            break;
        }
    testaPtr = testaPtr->nextPtr;
    }

    if(controllo == 1){
        printf("la stringa e' palindroma\n");
    }
    else{
        printf("la stringa non e' palindroma\n");
    }

    cancella(&testaPtr);
}

void push(PilaPtr *topPtr, char c){
    PilaPtr newPtr = malloc(sizeof(Pila));
    
    if(newPtr == NULL){
        printf("memoria esaurita\n");
        return;
    }

    newPtr->c = c;
    newPtr->nextPtr = *topPtr;
    *topPtr = newPtr;
}

void cancella(PilaPtr* topPtr){
    if(topPtr == NULL){
        printf("la pila e' vuota\n");
        return;
    }
    PilaPtr temp = NULL;
    while(topPtr != NULL){
        temp = *topPtr;
        *topPtr = (*topPtr)->nextPtr;
        free(temp);
    }
}
