/*(stringhe che finiscono con ed)scrivete un programma che legga una serie di stringhe e stampi solo quelle che finiscono con le lettere ed*/
#include <stdio.h>
#include <string.h>

#define SIZE 100
#define MAX_RIGHE 10

void chiediStringa(char stringa[]);

int main(){
    char stringhe[MAX_RIGHE][SIZE];
    char stringaRicerca[] = "ed";
    int nRighe = 0;

    printf("inserisci il numero di stringhe da inserire(max 10): ");
    scanf("%d", &nRighe);
    while(getchar() != '\n');

    if(nRighe > MAX_RIGHE || nRighe < 1){
        printf("valore non valido!\n");
        return 1;
    }

    for (size_t i = 0; i < nRighe; i++){
        printf("inserisci stringa %d: ", i+ 1);
        chiediStringa(stringhe[i]);
    }

    for (size_t i = 0; i < nRighe; i++){
        int lunghezza = strlen(stringhe[i]);
        if (lunghezza >= 2 && strcmp(&stringhe[i][lunghezza - 2], stringaRicerca) == 0) {
            printf("%s\n", stringhe[i]);
        }

    }
}

void chiediStringa(char stringa[]){
    fgets(stringa, SIZE, stdin);
    stringa[strcspn(stringa, "\n")] = '\0';
}