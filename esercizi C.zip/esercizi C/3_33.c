/*modificate il programma che avete scritto precedentemente in modo che stampi un quadrato vuoto*/
#include <stdio.h>

int main() {
    int lato;
    int i = 0, j;

    // Richiede all'utente di inserire la dimensione del lato
    printf("Inserisci la dimensione del lato del quadrato (tra 1 e 20): ");
    scanf("%d", &lato);

    // Controlla che il lato sia valido
    if (lato >= 1 && lato <= 20) {
        // Stampa il quadrato vuoto
        while (i < lato) {
            j = 0;
            while (j < lato) {
                // Stampa asterisco se è bordo (prima o ultima riga/colonna)
                if (i == 0 || i == lato - 1 || j == 0 || j == lato - 1) {
                    printf("*");
                } else {
                    printf(" ");
                }
                j++;
            }
            printf("\n"); // Va a capo dopo ogni riga
            i++;
        }
    } else {
        printf("Errore: il lato deve essere compreso tra 1 e 20.\n");
    }

    return 0;
}