#include <stdio.h>

int main(){
    //a) stampare il valore del settimo elemento di un array di caratteri f
    char f[10] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    printf("il settimo elemento dell'array f e': %c\n", f[6]);

    //b) inserire un valore nell'elemento 4 di un array b unidimensionale di elementi in virgola mobile
    double m[10] = {0};
    m[3] = 5.45;
    printf("il quarto elemento dell'array b e: %.2f\n", m[3]);

    //c) inizializzare a 8 ognuno dei 5 elementi di un array intero unidimensionale g
    int g[5] = {0};

    for(size_t y = 0; y < 5; y++){
        g[y] = 8;
    }

    for(size_t x = 0; x < 5; x++){
        printf("%d ", g[x]);
    }

    puts("");

    //d) sommare gli elementi dell'array c di 100 elementi in virgola mobile
    double c[100] = {1};

    for(size_t z = 1; z < 100; z++){
        c[z] = c[z-1] + 1;
    }

    double somma = 0;
    for(size_t h = 0; h < 100; h++){
        somma += c[h];
    }

    printf("la somma degli elementi dell'arrai c e': %.2f\n", somma);

    //e) copiare l'array a nella prima porzione dell'array b. supponete che a abbia 11 elementi, b ne abbia 34 
    //ed entrambi abbiano lo stesso tipo di elementi

    int a[11] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
    int b[34] = {0};

    for(size_t r = 0; r < 11; r++){
        b[r] = a[r];
    }

    for(size_t j = 0; j < 34; j++){
        printf("%d ", b[j]);
    }
    puts("");

    //f) determinare e stampare il valore più piccolo e il valore più grande contenuti nell'array w di 99 elementi in virgola mobile
    double w[99] = {0};
    
    for(size_t x = 0; x < 99; x++){ //riempio l'array con valori random
        w[x] = 1.4 * x;
        if(x > 20){
            w[x] /= 2;
        }
        if(x > 60){
            w[x] = (double)x / 3;
        }
    }
     
    double min = w[0];
    double max = w[0];

    for (size_t x = 1; x < 99; x++) {
        if (w[x] < min) {
            min = w[x];
        }
        if (w[x] > max) {
            max = w[x];
        }
    }

    printf("Il maggiore e': %.2f\nIl minore e': %.2f\n", max, min);


}