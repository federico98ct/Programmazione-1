/*scrivete un programma che continui a stampare i multipli del numero intero 2. il vostro ciclo non deve terminare*/
#include <stdio.h>

int main(){

    int i = 1;

    while (1)
    {
        printf("%d\n", 2 *i);
        i++;
    }
    
}