/*scrivete un programma che sommi una sequenza di interi. supponete che il primo intero letto con scanf specifichi il numero
di valori che devono ancora essere inseriti. il vostro programma deve leggere solo un valore a ogni esecuzione di scanf*/
#include <stdio.h>

int main(){
    int massimo = 0;
    int numero = 0;
    int somma = 0;

    printf("inserisci il numero di interi che vuoi sommare: ");
    scanf("%d", &massimo);

    for(int i = 1; i <= massimo; i++){
        printf("inserisci un numero: ");
        scanf("%d", &numero);
        somma += numero;
    }

    printf("la somma di questi %d numeri e': %d", massimo, somma);
}