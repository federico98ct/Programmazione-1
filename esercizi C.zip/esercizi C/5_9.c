/*un garage fa pagare una tariffa minima di $2.00 per parcheggio fino a tre ore, più $0.50 all'ora per ogni ora aparte di essa
oltre le tre ore. il costo massimo per un periodo di 24 ore è di $10.00. supponete che nessuna macchina resti parcheggiata per 
più di 24 ore. scrivete un programma che calcoli e stampi i costi del parcheggio per ciascuno dei tre clienti che ieri hanno
parcheggiato le loro auto in questo garage. dovete inserire le ore di parcheggio per ogni cliente. il vostro programma deve stampare
i risultati in un formato tabellare e deve calcolare e stampare il totale degli incassi di ieri. il programma deve usare la funzione 
calculateCharges per determinare il costo per ogni cliente.*/
#include <stdio.h>

double calcoloImporto(double ore);

int main(){

    double ore = 0;
    double totaleOre = 0;
    double totaleImporto = 0;

    printf("%-10s%-12s%-12s\n", "auto", "ore", "importo");
    for(int i = 1; i <= 3; i++){

        printf("inserisci numero di ore della %d' macchina: ", i);
        scanf("%lf", &ore);
        totaleOre += ore;
        
        double importo = calcoloImporto(ore);
        printf("%-10d%-12.2f%-12.2f\n", i, ore, importo);
        totaleImporto += importo;
    }

    printf("%-10s%-12.2f%-12.2f", "TOTALE", totaleOre, totaleImporto);
}


double calcoloImporto(double ore){
    double tariffaBase = 2.00;
    double tariffaMax = 10.00;
    double tariffaExtra = 0.50;
    

    if(ore <= 3){
        return tariffaBase;
    }
    
    double tariffa = tariffaBase + (ore - 3)*tariffaExtra;

    if(tariffa >= tariffaMax){
        return tariffaMax;
    }

    return tariffa;

}