/*inserite un numero intero binario (di 5 cifre o meno) contenente soltanto valori pari a 0 o 1 e stampate il suo equivalente 
decimale */
#include <stdio.h>

int main(){
    int binario =0;
    int numero =0;
    int temporaneo =0;
    int modulo =0;
    int potenza =1;

    printf("inserisci un numero binario: ");
    scanf("%d", &binario);

    temporaneo = binario;
    while (temporaneo > 0)
    {
        modulo = temporaneo%10;
        if(modulo !=1 && modulo != 0 || binario > 11111){
            printf("inserisci un numero binario valido (formato da 0 e 1) e che non superi le 5 cifre\n");
            return 1;
        }
        else{
            numero = modulo * potenza + numero;
            potenza *= 2;
        }
        temporaneo /= 10;   
    }
    printf(" (binario) %d ---> %d (decimale)", binario, numero);
}