/*scrivete una funzione che riceva il tempo espresso come tre argomenti interi (per ore, minuti e secondi) e restitisci il 
numero dei secondi da quando l'orologio ha battuto le 12 l'ultima volta. usate questa funzione per calcolare la quantità di tempo
in secondi tra due orari, entrambi contenuti dentro un ciclo dell'orologgio di 12 ore*/
#include <stdio.h>

int tempoInSecondi(int ore, int minuti, int secondi);

int main(){
    int ore = 0;
    int minuti = 0;
    int secondi = 0;
    int tempo1 = 0;
    int tempo2 = 0;

    while(1){
        printf("inserisci ore, minuti e secondi(primo orario): "); //primo orario
        if(scanf("%d%d%d", &ore, &minuti, &secondi) == 3 && ore >= 0 && ore <= 12 && minuti >=0 && minuti <= 59 && secondi >= 0 && secondi <= 59){
            tempo1 = tempoInSecondi(ore, minuti, secondi);
        }
        else{
            printf("inserisci dati validi");
            break;
        }

        printf("inserisci ore, minuti e secondi(secondo orario): ");//secondo orario
        if(scanf("%d%d%d", &ore, &minuti, &secondi) == 3 && ore >= 0 && ore <= 12 && minuti >=0 && minuti <= 59 && secondi >= 0 && secondi <= 59){
        tempo2 = tempoInSecondi(ore, minuti, secondi);
        }
        else{
            printf("inserisci dati validi");
            break;
        }

        int differenza = (tempo1 > tempo2 ? tempo1 - tempo2 : tempo2 - tempo1);
        printf("la differenza in secondi tra %d e %d e' di: %d\n", tempo2, tempo1, differenza);

    }
}    

int tempoInSecondi(int ore, int minuti, int secondi){
    
    return (ore * 3600) + (minuti * 60) + secondi;
}
    