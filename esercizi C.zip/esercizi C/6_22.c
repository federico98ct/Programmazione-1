/*usate un array bidimensionale per risolvere il seguente problema. un'azienda ha quattro agenti di vendita (da 1 a 4) che vendono
cinque differenti prodotti (da 1 a 5). una volta al giorno, ogni agente di vendita consegna una distinta per ogni tipo differente di prodotto 
venduto. ogni distinta contiene:
a) il numero dell'agente di vendita
b) il numero del prodotto
c) il valore totale in dollari di quel prodotto venduto quel giorno
in questo modo ogni agente di vendita consegna tra 0 e 5 distinte di vendita al giorno. supponete che siano disponibili le informazioni
contenute in tutte le distinte per l'ultimo mese. scrivete un programma che legga queste informazioni per le vendite dell'ultimo mese
e riepiloghi le vendite totali per agente di vendita e per prodotto. tutti i totali devono essere memorizzati nell'array bidimensionale
sales. Dopo aver elaborato tutte le informazioni per l'ultimo mese, stampate i risultati in formato tabellare con ogni colonna che
rappresenta uno specifico agente di vendita e ogni riga che rappresenta uno specifico prodotto. calcolare il totale parziale di ogni 
riga per ottenere il totale delle vendite realizzato da ogni agente di vendita per l'ultimo mese. la vostra stampa tabellare deve
includere questi totali parziali alla destra delle righe sommate e in fondo alle colonne sommate */
#include <stdio.h>
#define AGENTI 4
#define PRODOTTI 5

int main(){
    int sales[PRODOTTI][AGENTI] = {0};

    for (size_t agente = 0; agente < AGENTI; agente++){

        for (size_t prodotto = 0; prodotto < PRODOTTI; prodotto++){

            printf("agente %zu inserisci il totale mensile del prodotto %zu: ", agente + 1, prodotto + 1);
            scanf("%d", &sales[prodotto][agente]);
        }
        
    }

    printf("        ");
    for(size_t agente = 0; agente < AGENTI; agente++){

        printf("%20s %zu", "agente",agente + 1);
    }

    printf("%20s\n", "totale");

    for (size_t prodotto = 0; prodotto < PRODOTTI; prodotto++){
        int sommaProdotto = 0;
        printf("%s %zu", "prodotto",prodotto + 1);
        
        for (size_t agente = 0; agente < AGENTI; agente++){

            printf("%20d", sales[prodotto][agente]);
            sommaProdotto += sales[prodotto][agente];
        }

        printf("%20d", sommaProdotto);
        puts("");
    }

    printf("totale"); 

    for (size_t agente = 0; agente < AGENTI; agente++){
        int sommaAgente = 0;

        for (size_t prodotto = 0; prodotto < PRODOTTI; prodotto++){

            sommaAgente += sales[prodotto][agente];
        }
        printf("%24d", sommaAgente);
    }
    
    
}