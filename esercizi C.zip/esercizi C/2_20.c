/*stampate il diametro, la circonferenza e l'area di un cerchio con un raggio pari a 2.
usate il valore 3,14159 per π. usate le seguenti formule: diametro = 2r, circonferena = 2π𝑟 e area = πr^2. 
effettuate ognuno di questi calcoli all'interno dell'istruzione printf e usate la specifica
di conversione %f */

#include <stdio.h>

int main()
{
    float raggio = 2;
    float pigreco = 3.14159;

    printf("il diametro e' : %f\n", 2*raggio);
    printf("la circonferenza e' : %f\n", 2*pigreco*raggio);
    printf("l'area e' : %f\n", pigreco*raggio*raggio);

}