/*(simulazione di un supermercato)*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct coda{
    int attesa;
    struct coda* nextPtr;
};

typedef struct coda Coda;
typedef Coda* CodaPtr;

void enqueue(CodaPtr* headPtr, CodaPtr* tailPtr, int n);
void dequeue(CodaPtr* headPtr, CodaPtr* tailPtr);
void cancellaCoda(CodaPtr* headPtr, CodaPtr* tailPtr);

int main(){
    printf("**benvenuto nel programma di simulazione di supermercato!**\n");
    srand(time(NULL));
    int cliente = 0;

    CodaPtr testaPtr = NULL;
    CodaPtr codaPtr = NULL;

    int tempo_arrivo = 1 + rand() % 4; // il primo cliente arriva fra 1 e 4 minuti
    int attesa_max = 0;
    int cliente_max = 0;

    for(size_t tempo = 0; tempo < 720; tempo++){

        if(tempo == tempo_arrivo){ 
            printf("e' arrivato un cliente!\n");
            int tempo_servizio = 1 + rand() % 4;
            
            int tempo_attesa;
            if(codaPtr == NULL){
                tempo_attesa = tempo_servizio + tempo;
            }
            else{
                tempo_attesa = codaPtr->attesa + tempo_servizio;
            }

            int attesa_reale;
            if(tempo > tempo_servizio){
                attesa_reale = tempo_attesa - tempo;
            }
            else{
                attesa_reale = tempo_servizio;
            }

            if(attesa_reale > attesa_max){
                attesa_max = attesa_reale;
            }

            enqueue(&testaPtr, &codaPtr, tempo_attesa);
            cliente++;

            tempo_arrivo = tempo + (1 + rand() % 4);

        }

        if(testaPtr != NULL && testaPtr->attesa == tempo){
            printf("un cliente e' stato servito\n");
            dequeue(&testaPtr, &codaPtr); 
            cliente--;
        }

        printf("[minuto %zu] clienti in coda: %d\n", tempo, cliente);
        if(cliente > cliente_max){
            cliente_max = cliente;
        }
    }

    printf("numeri massimo di clienti in coda: %d\n", cliente_max);
    printf("tempo d'attesa massimo: %d\n", attesa_max);
    cancellaCoda(&testaPtr, &codaPtr);
}

void enqueue(CodaPtr* headPtr, CodaPtr* tailPtr, int n){
    CodaPtr newPtr = malloc(sizeof(Coda));

    if(newPtr != NULL){
        newPtr->attesa = n;
        newPtr->nextPtr = NULL;

        if(*headPtr == NULL){
            *headPtr = newPtr;
        }
        else{
            (*tailPtr)->nextPtr = newPtr;
        }
        *tailPtr = newPtr;
    }
    else{
        printf("memoria piena\n");
        return;
    }
}

void dequeue(CodaPtr* headPtr, CodaPtr* tailPtr){
    CodaPtr temp = *headPtr;
    *headPtr = (*headPtr)->nextPtr;

    if(*headPtr == NULL){
        *tailPtr = NULL;
    }

    free(temp);
}

void cancellaCoda(CodaPtr* headPtr, CodaPtr* tailPtr) {
    while (*headPtr != NULL) {
        CodaPtr temp = *headPtr;
        *headPtr = (*headPtr)->nextPtr;
        free(temp);
    }
    *tailPtr = NULL; 
}