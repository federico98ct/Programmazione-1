/*scrivete una funzione toQualityPoints che riceva in ingresso la media dei voti di uno studente e restituisca 4 se questa è
compresa nell'intervallo 90-100, 3 se è tra 80-89, 2 se è tra 70-79, 1 se è tra 60-69 e 0 se la media è più bassa di 60*/
#include <stdio.h>

int toQualityPoints(int media);

int main(){
    int media = 0;
    printf("inserisci la media dello studente(0-100): ");
    if(scanf("%d", &media) == 1 && media >= 0 && media <= 100){
        printf("la sua valutazione e': %d", toQualityPoints(media));
    }
    else
        printf("inserisci dati validi");
}

int toQualityPoints(int media){
    if(media >= 90){
        return 4;
    }
    if(media >= 80){
        return 3;
    }
    if(media >= 70){
        return 2;
    }
    if(media >= 60){
        return 1;
    }
    else
        return 0;

}