/*scrivete un programma che simuli il lancio di una moeta. per ogni lancio della moneta il programma deve stampare testa o croce
fate lanciare al programma la moneta 100 volte e contate il numero di volte in cui compare ogni lato della moneta. stampate i risultati.
il programma deve chiamare una funzione separata flip che non riceve alcun argomento e restituisce zero per croce e 1 per testa.
se il programma simula in maniera realistica il lancio della moneta, allora ogni lato della moneta deve comparire approssimativamente 
la metà delle volte.*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int moneta(void);

int main(){
    int testa = 0;
    int croce = 0;

    srand(time(NULL));

    for(int i = 1; i <= 100; i++){
        
        if(moneta() == 1){
            testa += 1;
            //printf("testa\n");
        }
        else
            croce +=1;
            //printf("croce\n");
    }
    printf("risultati finali\n");
    printf("testa: %d\n", testa);
    printf("croce: %d\n", croce);
}

int moneta(){
    return rand() % 2;
}