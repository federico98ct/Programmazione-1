/*usando un approccio simile a quello dell'esercizio 3_23, trovate i due valori più grandi tra 10 numeri. potete inserire 
ogni numero solo una volta*/

#include <stdio.h>

int main (){

    int numero =0;
    int massimo =0;
    int massimo_2 =0;
    int i =1;

    while (i <= 10){

        printf("inserisci il %d numero: ", i);
        scanf("%d", &numero);
        
        if (numero == massimo || numero == massimo_2) {
            printf("Numero già inserito! Inserisci un numero diverso.\n");
            continue; // Salta al prossimo ciclo senza incrementare i
        }     
        if (numero >= massimo){
            massimo_2 = massimo;
            massimo = numero; 
        }
        else if (numero >= massimo_2){
            massimo_2 = numero;
        }
        i++;
    }

    printf("il massimo e': %d\n", massimo);
    printf("il secondo numero piu' grande e': %d", massimo_2);
}
