/*(invertire le parole in una frase) scrivete un programma che ricevi in ingresso una riga di testo e usi una pila per stampare 
la riga in ordine inverso*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct pila{
    char c;
    struct pila* nextPtr;
};

typedef struct pila Pila;
typedef Pila* PilaPtr;

void push(PilaPtr* topPtr, char c);
void stampaLista(PilaPtr topPtr);
void cancella(PilaPtr* topPtr);

#define SIZE 100
int main(){
    printf("inserisci una stringa: ");
    char stringa[SIZE];
    fgets(stringa, SIZE, stdin);
    stringa[strcspn(stringa, "\n")] = '\0';

    PilaPtr testaPtr = NULL;
    int dimensione = strlen(stringa);
    for(size_t i = 0; i <dimensione; i++){
        push(&testaPtr, stringa[i]);
    }
    printf("la stringa inversa e': ");
    stampaLista(testaPtr);
    cancella(&testaPtr);
}

void push(PilaPtr* topPtr, char c){
    PilaPtr newPtr = malloc(sizeof(Pila));
    if(newPtr != NULL){
        newPtr->c = c;
        newPtr->nextPtr = *topPtr;
        *topPtr = newPtr;
    }
    else{
        printf("nessuna memoria disponibile\n");
    }
}

void stampaLista(PilaPtr topPtr){
    if(topPtr == NULL){
        printf("la pila e' vuota\n");
        return;
    }
    while(topPtr != NULL){
        printf("%c", topPtr->c);
        topPtr = topPtr->nextPtr;
    }
}

void cancella(PilaPtr* topPtr){
    if(topPtr == NULL){
        printf("la pila e' vuota\n");
        return;
    }
    PilaPtr temp = NULL;
    while(topPtr != NULL){
        temp = *topPtr;
        *topPtr = (*topPtr)->nextPtr;
        free(temp);
    }
}
