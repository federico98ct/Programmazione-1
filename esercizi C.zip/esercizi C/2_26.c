/*scrivete un programma che riceva in ingresso un numero di cinque cifre, separi il numero nelle sue cifre individuali e stampi
le cifre ciascuna separata dall'altra da tre spazi.*/

#include <stdio.h>

int main()
{
    int numero= 0;

    printf("inserisci un numero a cinque cifre: ");
    scanf("%d", &numero);

    printf("%d   %d   %d   %d   %d",
        (numero / 10000)%10,
        (numero / 1000)%10,
        (numero / 100)%10,
        (numero / 10)%10,
        numero %10
    );
}