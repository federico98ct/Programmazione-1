/*(stringhe che cominciano con b) scrivete un programma che legga una serie di stringhe e stampi solo quelle che cominciano
con la lettera b*/
#include <stdio.h>
#include <string.h>

#define SIZE 100
#define MAX_RIGHE 10

void chiediStringa(char stringa[]);

int main(){
    char stringhe[MAX_RIGHE][SIZE];
    int nRighe = 0;
    char carattere = 'b';

    printf("inserisci il numero di righe da inserire (10 max): ");
    scanf("%d", &nRighe);
    getchar();

    if(nRighe > MAX_RIGHE || nRighe < 1){
        printf("valore non valido\n");
        return 1;
    }

    for (int i = 0; i < nRighe; i++){ //inserimento stringhe
        printf("inserisci stringa %d: ", i+1);
        chiediStringa(stringhe[i]);
    }


    for (size_t i = 0; i < nRighe; i++){
        char *ptr = (char *) memchr(stringhe[i], carattere, 1);
        if(ptr != NULL){
            printf("la stringa : %s inizia per %c\n", ptr, carattere);
        }
        else{
            printf("la stringa : %s non inizia per %c\n", stringhe[i], carattere);
        }
    }
}

void chiediStringa(char stringa[]){
    fgets(stringa, SIZE, stdin);
    stringa[strcspn(stringa, "\n")] = '\0';
}