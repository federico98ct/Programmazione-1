/*scrivete un programma basato sull'esercizio precedente che legga diverse righe di testo e una stringa di ricerca e che usi la
funzione strstr per determinare il totale delle volte in cui la stringa ricorre nelle righe di testo. stampate il risultato*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 100
#define MAX_LINES 10 // Numero massimo di righe di testo

void chiediStringa(char array[]);

int main() {
    char righe[MAX_LINES][SIZE]; // Array di stringhe per memorizzare più righe
    char stringaRicerca[SIZE] = "";
    int numRighe, i, occorrenze = 0;

    printf("Quante righe vuoi inserire? (max %d): ", MAX_LINES);
    scanf("%d", &numRighe);
    getchar(); // Consumare il newline lasciato da scanf

    if (numRighe > MAX_LINES || numRighe < 1) {
        printf("Numero non valido!\n");
        return 1;
    }

    // Lettura delle righe di testo
    for (i = 0; i < numRighe; i++) {
        printf("Inserisci riga %d: ", i + 1);
        chiediStringa(righe[i]);
    }

    // Lettura della stringa da cercare
    printf("Inserisci la stringa da ricercare: ");
    chiediStringa(stringaRicerca);

    // Ricerca della stringa in tutte le righe
    for (i = 0; i < numRighe; i++) {
        char *searchPtr = strstr(righe[i], stringaRicerca);
        while (searchPtr != NULL) {
            occorrenze++;
            searchPtr = strstr(searchPtr + 1, stringaRicerca);
        }
    }

    // Stampa del numero totale di occorrenze
    printf("La stringa \"%s\" ricorre %d volte nelle righe di testo.\n", stringaRicerca, occorrenze);

    return 0;
}

void chiediStringa(char array[]) {
    fgets(array, SIZE, stdin);
    array[strcspn(array, "\n")] = '\0'; // Rimozione del newline
}