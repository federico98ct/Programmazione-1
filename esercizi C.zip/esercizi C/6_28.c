/*nel capitolo 12 esploreremo la struttura di dati ad albero per la ricerca binaria ad alta velocità. una caratteristica
dell'albero di ricerca binaria e quella che i valori duplicati sono scartati quando vengono fatte inserzioni al suo interno. questa
è detta eliminazione dei duplicati. scrivete un programma che produca 20 numeri a caso tra 1 e 20. il programma deve memorizzare
tutti i valori non duplicati in un array. usate l'array più piccolo possibile per eseguire questo compito.*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define SIZE 20

int main(){
    srand(time(NULL));
    int dimensione = 0;
    int numeri[SIZE];

    for(size_t i = 0; i < SIZE; i++){

        int numero = 1 + (rand() % 20);
        int copia = 1;

        printf("%d ", numero);

        for (size_t x = 0; x < dimensione; x++){
            if(numero == numeri[x]){
                copia = 0;
                break;
            }
        }

        if(copia == 1){
            numeri[dimensione] = numero;
            dimensione++;
        }  
    }
    
    puts("");

    for(size_t y = 0; y < dimensione; ++y){
        printf("%d ", numeri[y]);
    }
}