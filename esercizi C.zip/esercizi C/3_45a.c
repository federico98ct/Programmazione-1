/*scrivete un programma che lagga un numero intero non negativo e calcoli e stampi il suo fattoriale.*/
#include <stdio.h>

int main(){
    int numero = 0;
    int fattoriale =1;

    printf("inserisci un numero: ");
    scanf("%d", &numero);

    if(numero >=0){
        while (numero > 0)
        {
            fattoriale *= numero;
            numero--;
        }
        printf("il suo fattoriale e': %d", fattoriale);
    }
    else
        printf("inserisci un numero non negativo");
}