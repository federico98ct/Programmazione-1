/*scrivete un programma che simuli il lancio di due dadi. il programma deve usare due volte rand per lanciare, rispettivamente,
il primo dado e il secondo dado, poi deve calcolare la somma dei due valori. poichè ogni dado può mostrare sulla faccia superiore
un valore intero da 1 a 6, la somma dei due valori varierà allora da 2 a 12, con 7 che è la somma più frequente e 2 e 12 che sono
le somme meno frequenti. il vostro programma deve lanciare i due dadi 36.000 volte. fate un array unidimensionale per annotare il 
numero delle volte in cui compare ogni possibile somma. stampate i risultati in un formato tabellare. stabilite se i totali sono 
ragionevoli: per esempio, vi sono sei modi di ottenere um risultato 7, quindi approssimativamente un sesto di tutti i lanci deve 
avere come somma 7 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define LANCI 36000
#define SIZE 13

int lancioDado(void);
void stampaRisultati(const int a[]);

int main(){
    srand(time(NULL));
    int count[SIZE] = {0};

    for(size_t i = 0; i < LANCI; i++){

        int dado1 = lancioDado();
        int dado2 = lancioDado();
        int somma = dado1 + dado2;
        
        count[somma]+=1; 
    }

    stampaRisultati(count);

}

int lancioDado(void){
    return 1 + rand() % 6;
}

void stampaRisultati(const int a[]){
    for (size_t i = 2; i < SIZE; i++){
        printf("la somma %d e' uscita: %d volte\n", i, a[i]);
    }
}