/*scrivete un programma che legga due interi e determini e stampi se il primo è un multiplo del secondo. 
usate l'operatore di resto*/

#include <stdio.h>

int main()
{
    int numero1= 0;
    int numero2= 0;

    printf("inserite due numeri: ");
    scanf("%d %d", &numero1, &numero2);

    int resto= numero1 % numero2;

    if(resto == 0)
        printf("%d e' multiplo di %d", numero1, numero2);
        
    if(resto != 0)
        printf("%d non e' multiplo di %d", numero1, numero2);
}