#include <stdio.h>
#include <stdlib.h>

int moltiplicazione(int a, int b);

int main(){
    int numero1 = 0;
    int numero2 = 0;

    printf("inserisci due numeri interi: ");
    scanf("%d%d", &numero1, &numero2);

    printf("il risultato e': %d\n", moltiplicazione(numero1, numero2));
}

int moltiplicazione(int a, int b){

    if(b == 0 ){
        return 0;
    }
    
    if (b > 0){
        return a + moltiplicazione(a, b- 1);
    }
    else{
        return -moltiplicazione(a, -b);
    }
}