/*una grande compagniachimica paga il suo personale addetto alle vendite su commissione. 
il personale addetto alle vendite riceve $200 alla settimana più il 9% delle vendite lorde per quella settimana.
per esempio, un addetto alle vendite che vende $5000 di prodotti chimici in una settimana riceve $200 più
il 9% di $5000, cioè un totale di $650. sviluppare un programma che utilizzi scanf per leggere le vendite lorde di ogni addetto
alle vendite nell'ultima settimana e calcoli e stampi i guadagni di quell'addetto. elaborate i dati di un addetto alla volta. */

#include <stdio.h>

int main()
{
    const int base_stipendio =200;
    double vendite =0;

    while (vendite >= 0)
    {
        printf("\ninserire le vendite in dollari (-1 per uscire): ");
        scanf("%lf", &vendite);
    
        if(vendite <0)
            break;

        double totale_stipendio = base_stipendio + (vendite*9/100);
        printf("lo stipendio e': $%.2f\n", totale_stipendio);
    }
    
}